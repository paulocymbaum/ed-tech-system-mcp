/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AppLayout } from './components/templates/AppLayout';
import { StudentDashboardView } from './views/StudentDashboardView';
import { LessonDetailView } from './views/LessonDetailView';
import { TeacherDashboardView } from './views/TeacherDashboardView';
import { RoleSelectView } from './views/RoleSelectView';
import { WeeklyPlanView } from './views/WeeklyPlanView';
import { ResourcesView } from './views/ResourcesView';
import { StudentsView } from './views/StudentsView';

const MainRouter: React.FC = () => {
  const { currentPath, role } = useApp();

  switch (currentPath) {
    case 'role-select':
      return <RoleSelectView />;

    case 'lesson-plans':
      return <LessonDetailView />;

    case 'weekly-plan':
      return <WeeklyPlanView />;

    case 'resources':
      return <ResourcesView />;

    case 'my-students':
      return <StudentsView />;

    case 'activities':
    case 'assessment':
    case 'dashboard':
    default:
      return role === 'teacher' ? <TeacherDashboardView /> : <StudentDashboardView />;
  }
};

export default function App() {
  return (
    <AppProvider>
      <AppLayout>
        <MainRouter />
      </AppLayout>
    </AppProvider>
  );
}
