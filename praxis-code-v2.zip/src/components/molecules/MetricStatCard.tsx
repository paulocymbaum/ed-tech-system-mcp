import React from 'react';

export interface MetricStatCardProps {
  icon: React.ReactNode | string;
  iconBg?: string;
  iconColor?: string;
  categoryLabel: string;
  title: string;
  badgeText?: string;
  badgeVariant?: 'amber' | 'blue' | 'emerald' | 'purple' | 'neutral';
  footerText?: string;
  progressPercent?: number;
  onClick?: () => void;
  className?: string;
}

export const MetricStatCard: React.FC<MetricStatCardProps> = ({
  icon,
  iconBg = 'bg-indigo-50 border-indigo-100',
  iconColor = 'text-indigo-600',
  categoryLabel,
  title,
  badgeText,
  badgeVariant = 'blue',
  footerText,
  progressPercent,
  onClick,
  className = '',
}) => {
  const badgeClasses = {
    amber: 'text-amber-700 bg-amber-50 border-amber-200/80',
    blue: 'text-blue-700 bg-blue-50 border-blue-200/80',
    emerald: 'text-emerald-700 bg-emerald-50 border-emerald-200/80',
    purple: 'text-purple-700 bg-purple-50 border-purple-200/80',
    neutral: 'text-slate-600 bg-slate-50 border-slate-200',
  };

  return (
    <div
      onClick={onClick}
      className={`bg-white p-4.5 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between transition-all duration-200 hover:shadow-sm ${
        onClick ? 'cursor-pointer hover:border-blue-300' : ''
      } ${className}`}
    >
      <div className="flex items-center space-x-3.5 min-w-0">
        <div
          className={`w-11 h-11 rounded-xl flex items-center justify-center font-bold text-xl shrink-0 border ${iconBg} ${iconColor}`}
        >
          {icon}
        </div>
        <div className="min-w-0">
          <p className="text-xs text-slate-400 font-semibold truncate">{categoryLabel}</p>
          <h3 className="text-sm font-bold text-slate-900 truncate mt-0.5">{title}</h3>
          {footerText && (
            <p className="text-[11px] text-slate-500 font-medium mt-0.5 truncate">{footerText}</p>
          )}
        </div>
      </div>
      {badgeText && (
        <span
          className={`text-xs font-semibold px-2.5 py-1 rounded-lg border whitespace-nowrap shrink-0 ml-3 ${badgeClasses[badgeVariant]}`}
        >
          {badgeText}
        </span>
      )}
    </div>
  );
};
