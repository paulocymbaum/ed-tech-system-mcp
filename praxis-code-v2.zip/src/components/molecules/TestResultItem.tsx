import React from 'react';
import { CheckCircle2, Clock, AlertCircle } from 'lucide-react';

export interface TestResultItemProps {
  testNumber: number;
  label: string;
  status: 'passed' | 'pending' | 'running' | 'failed';
}

export const TestResultItem: React.FC<TestResultItemProps> = ({
  testNumber,
  label,
  status,
}) => {
  return (
    <div
      className={`flex items-center justify-between p-2.5 rounded-xl border text-xs transition-all ${
        status === 'passed'
          ? 'bg-emerald-50/80 border-emerald-200/80 text-emerald-900'
          : status === 'running'
          ? 'bg-blue-50/80 border-blue-200 text-blue-900'
          : status === 'failed'
          ? 'bg-rose-50 border-rose-200 text-rose-900'
          : 'bg-white border-slate-200 text-slate-700'
      }`}
    >
      <div className="flex items-center space-x-2.5 min-w-0 pr-2">
        {status === 'passed' && (
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
        )}
        {status === 'running' && (
          <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin shrink-0" />
        )}
        {status === 'pending' && (
          <Clock className="w-4 h-4 text-amber-500 shrink-0" />
        )}
        {status === 'failed' && (
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
        )}
        <span className="font-medium text-[11px] truncate">
          Teste {testNumber}: {label}
        </span>
      </div>

      <span
        className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded shrink-0 ${
          status === 'passed'
            ? 'text-emerald-700 bg-emerald-100/70'
            : status === 'running'
            ? 'text-blue-700 bg-blue-100 animate-pulse'
            : status === 'failed'
            ? 'text-rose-700 bg-rose-100'
            : 'text-amber-700 bg-amber-100/80'
        }`}
      >
        {status === 'passed'
          ? 'Passou'
          : status === 'running'
          ? 'Testando'
          : status === 'failed'
          ? 'Erro'
          : 'Aguardando'}
      </span>
    </div>
  );
};
