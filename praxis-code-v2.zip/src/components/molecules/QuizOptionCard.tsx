import React from 'react';

export interface QuizOptionCardProps {
  id: string;
  label: string;
  fractionVisual?: {
    total: number;
    filled: number;
  };
  isSelected: boolean;
  onSelect: () => void;
}

export const QuizOptionCard: React.FC<QuizOptionCardProps> = ({
  label,
  fractionVisual,
  isSelected,
  onSelect,
}) => {
  return (
    <button
      type="button"
      onClick={onSelect}
      className={`p-3.5 rounded-2xl border transition-all flex flex-col items-center justify-center text-center cursor-pointer active:scale-97 select-none ${
        isSelected
          ? 'bg-blue-50/90 border-blue-400 text-blue-800 shadow-xs'
          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100 hover:border-slate-300'
      }`}
    >
      {fractionVisual && (
        <div className="w-14 h-14 mb-2 relative">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 32 32">
            <circle cx="16" cy="16" r="14" fill="#e2e8f0" />
            <path
              d="M16 16 L16 2 A14 14 0 1 1 2 16 Z"
              fill={isSelected ? '#2563eb' : '#64748b'}
            />
          </svg>
        </div>
      )}
      <span className="text-xs font-bold">{label}</span>
    </button>
  );
};
