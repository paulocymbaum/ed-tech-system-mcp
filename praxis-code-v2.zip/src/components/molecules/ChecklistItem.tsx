import React from 'react';
import { Check } from 'lucide-react';

export interface ChecklistItemProps {
  id: string;
  stepNumber: number;
  title: string;
  subtitle: string;
  isChecked: boolean;
  onToggle: () => void;
}

export const ChecklistItem: React.FC<ChecklistItemProps> = ({
  stepNumber,
  title,
  subtitle,
  isChecked,
  onToggle,
}) => {
  return (
    <label
      onClick={onToggle}
      className={`flex items-start space-x-3 p-3.5 rounded-xl cursor-pointer border transition-all select-none ${
        isChecked
          ? 'bg-slate-50/90 border-slate-200/80'
          : 'bg-white border-slate-200 shadow-xs hover:bg-slate-50/60'
      }`}
    >
      <div
        className={`w-4.5 h-4.5 rounded-md mt-0.5 flex items-center justify-center border transition-colors shrink-0 ${
          isChecked
            ? 'bg-blue-600 border-blue-600 text-white'
            : 'border-slate-300 bg-white hover:border-blue-400'
        }`}
      >
        {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
      </div>
      <div className="text-xs">
        <span
          className={`font-bold ${
            isChecked ? 'line-through text-slate-400' : 'text-slate-800'
          }`}
        >
          Passo {stepNumber}: {title}
        </span>
        <p className="text-[11px] text-slate-500 mt-0.5 leading-snug">{subtitle}</p>
      </div>
    </label>
  );
};
