import React from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';

export interface RoleSwitcherProps {
  className?: string;
  size?: 'sm' | 'md';
}

export const RoleSwitcher: React.FC<RoleSwitcherProps> = ({ className = '', size = 'md' }) => {
  const { role, setRole, setCurrentPath } = useApp();

  const handleRoleSelect = (newRole: UserRole) => {
    setRole(newRole);
    // If on dashboard, keep user in the appropriate context
    if (newRole === 'teacher') {
      setCurrentPath('dashboard');
    } else {
      setCurrentPath('dashboard');
    }
  };

  const isSmall = size === 'sm';

  return (
    <div
      className={`bg-[#1e293b] p-1 rounded-full flex items-center select-none shadow-inner border border-slate-700/50 ${className}`}
    >
      <button
        type="button"
        onClick={() => handleRoleSelect('teacher')}
        className={`flex-1 py-1 px-3 rounded-full text-center transition-all duration-200 cursor-pointer ${
          isSmall ? 'text-[11px]' : 'text-xs'
        } font-semibold ${
          role === 'teacher'
            ? 'bg-blue-600 text-white shadow-sm'
            : 'text-slate-400 hover:text-white'
        }`}
      >
        Teacher
      </button>
      <button
        type="button"
        onClick={() => handleRoleSelect('student')}
        className={`flex-1 py-1 px-3 rounded-full text-center transition-all duration-200 cursor-pointer ${
          isSmall ? 'text-[11px]' : 'text-xs'
        } font-semibold ${
          role === 'student'
            ? 'bg-blue-600 text-white shadow-sm'
            : 'text-slate-400 hover:text-white'
        }`}
      >
        Student
      </button>
    </div>
  );
};
