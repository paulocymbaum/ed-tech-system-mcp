import React from 'react';
import { Play, CheckCircle2, ArrowRight } from 'lucide-react';
import { IVideoResource } from '../../types';

export interface VideoCardProps {
  video: IVideoResource;
  onPlay: (video: IVideoResource) => void;
  className?: string;
}

export const VideoCard: React.FC<VideoCardProps> = ({ video, onPlay, className = '' }) => {
  return (
    <div
      onClick={() => onPlay(video)}
      className={`group border border-slate-200/90 rounded-2xl overflow-hidden hover:border-blue-400 hover:shadow-md transition-all duration-200 bg-white flex flex-col cursor-pointer ${className}`}
    >
      <div className="relative aspect-video bg-slate-950 flex items-center justify-center overflow-hidden">
        {/* Abstract mathematical coding background */}
        <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-900 to-blue-950 flex items-center justify-center opacity-95 group-hover:scale-105 transition-transform duration-500">
          {video.embedFormula && (
            <div className="text-blue-300/40 font-mono text-lg font-bold select-none tracking-wider">
              {video.embedFormula}
            </div>
          )}
        </div>

        {/* Play Button Indicator */}
        <div className="relative z-10 w-12 h-12 rounded-full bg-red-600 group-hover:bg-red-500 text-white flex items-center justify-center shadow-lg transition-transform group-hover:scale-110">
          <Play className="w-5 h-5 fill-current ml-0.5" />
        </div>

        {/* Duration timestamp */}
        <span className="absolute bottom-2.5 right-2.5 bg-black/85 backdrop-blur-xs text-white text-[10px] font-mono font-medium px-2 py-0.5 rounded">
          {video.duration}
        </span>

        {/* Platform tag */}
        <span className="absolute top-2.5 left-2.5 bg-red-600/90 text-white text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded">
          {video.badge}
        </span>
      </div>

      <div className="p-3.5 flex flex-col flex-1 justify-between gap-3">
        <div>
          <h4 className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors leading-snug line-clamp-2">
            {video.title}
          </h4>
          <p className="text-[11px] text-slate-500 mt-1 flex items-center gap-1 font-medium">
            <span>{video.channel}</span>
            {video.verified && <CheckCircle2 className="w-3 h-3 text-blue-500 shrink-0 inline" />}
          </p>
        </div>

        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-blue-600 font-semibold">
          <span>Assistir aula em vídeo</span>
          <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
        </div>
      </div>
    </div>
  );
};
