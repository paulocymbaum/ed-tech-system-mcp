import React, { useState, useEffect } from 'react';
import { Play, Pause, Volume2, VolumeX } from 'lucide-react';

export interface AudioNarratorPlayerProps {
  title?: string;
  subtitle?: string;
  duration?: string;
  current?: string;
  className?: string;
}

export const AudioNarratorPlayer: React.FC<AudioNarratorPlayerProps> = ({
  title = 'Lesson Narration (Audio Lesson)',
  subtitle = 'Listen to Miss Sarah explain Fractions',
  duration = '08:30',
  current = '02:14',
  className = '',
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTimeSec, setCurrentTimeSec] = useState(134); // 02:14 in seconds
  const [isMuted, setIsMuted] = useState(false);
  const totalDurationSec = 510; // 08:30 in seconds

  useEffect(() => {
    let interval: any = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setCurrentTimeSec((prev) => (prev >= totalDurationSec ? 0 : prev + 1));
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const progressPercent = (currentTimeSec / totalDurationSec) * 100;

  return (
    <div
      className={`bg-slate-50 border border-slate-200/60 rounded-xl p-3 sm:p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${className}`}
    >
      <div className="flex items-center space-x-3 w-full sm:w-auto">
        <button
          type="button"
          onClick={() => setIsPlaying(!isPlaying)}
          aria-label={isPlaying ? 'Pausar áudio' : 'Reproduzir áudio'}
          className="w-9 h-9 rounded-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center shadow-md shadow-blue-600/20 transition-all cursor-pointer shrink-0 active:scale-95"
        >
          {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
        </button>
        <div>
          <div className="flex items-center space-x-2">
            <p className="text-xs font-bold text-slate-800">{title}</p>
            {isPlaying && (
              <span className="flex space-x-0.5 items-end h-3">
                <span className="w-0.5 h-2 bg-blue-600 animate-pulse"></span>
                <span className="w-0.5 h-3 bg-blue-600 animate-pulse delay-75"></span>
                <span className="w-0.5 h-1.5 bg-blue-600 animate-pulse delay-150"></span>
              </span>
            )}
          </div>
          <p className="text-[11px] text-slate-500">{subtitle}</p>
        </div>
      </div>

      <div className="flex items-center justify-between sm:justify-end space-x-3 text-xs text-slate-500 w-full sm:w-auto">
        <span className="font-mono text-[11px] tabular-nums text-slate-600 font-medium">
          {formatTime(currentTimeSec)} / {duration}
        </span>
        <div className="w-28 sm:w-36 bg-slate-200 h-1.5 rounded-full overflow-hidden">
          <div
            className="bg-blue-600 h-full rounded-full transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
        <button
          type="button"
          onClick={() => setIsMuted(!isMuted)}
          className="text-slate-400 hover:text-slate-700 p-1 transition cursor-pointer"
          title={isMuted ? 'Desmutar' : 'Mutar'}
        >
          {isMuted ? <VolumeX className="w-4 h-4 text-slate-400" /> : <Volume2 className="w-4 h-4 text-blue-600" />}
        </button>
      </div>
    </div>
  );
};
