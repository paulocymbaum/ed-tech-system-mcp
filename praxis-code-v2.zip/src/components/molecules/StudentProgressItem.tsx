import React from 'react';
import { IStudent } from '../../types';
import { ProgressBar } from '../atoms/ProgressBar';
import { Check, Clock, AlertTriangle } from 'lucide-react';

export interface StudentProgressItemProps {
  student: IStudent;
  onClick?: () => void;
}

export const StudentProgressItem: React.FC<StudentProgressItemProps> = ({ student, onClick }) => {
  const isAlert = !!student.hasAlert;

  return (
    <div
      onClick={onClick}
      className={`p-3.5 rounded-2xl transition-all duration-200 ${
        isAlert
          ? 'bg-rose-50/70 border border-rose-200 hover:bg-rose-100/60'
          : 'bg-slate-50 border border-slate-200/80 hover:bg-slate-100/70'
      } ${onClick ? 'cursor-pointer' : ''}`}
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-2.5">
          <div className="relative">
            <div
              className={`w-9 h-9 rounded-full ${student.avatarColor} text-white flex items-center justify-center font-bold text-xs shadow-xs`}
            >
              {student.initials}
            </div>
            <span
              className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full ring-2 ring-white ${
                isAlert ? 'bg-rose-500' : student.isOnline ? 'bg-emerald-500' : 'bg-slate-400'
              }`}
            />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-xs text-slate-900">{student.name}</span>
              <span className="text-[11px] text-slate-500 font-medium">({student.grade})</span>
            </div>
            <p
              className={`text-[11px] font-medium flex items-center gap-1 mt-0.5 ${
                isAlert ? 'text-rose-700 font-semibold' : 'text-slate-500'
              }`}
            >
              {isAlert ? (
                <AlertTriangle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
              ) : student.isOnline ? (
                <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              ) : (
                <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              )}
              <span className="truncate">{student.statusText}</span>
            </p>
          </div>
        </div>

        <span
          className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
            isAlert
              ? 'bg-rose-200/80 text-rose-800'
              : 'bg-slate-200/80 text-slate-700'
          }`}
        >
          {isAlert ? '⚠️ ' : '🔥 '}
          {student.streakDays} Dias
        </span>
      </div>

      <div className="mt-2.5 space-y-1">
        <div className="flex justify-between text-[11px] text-slate-500 font-medium">
          <span>Progresso Semanal</span>
          <span
            className={`font-bold tabular-nums ${
              isAlert ? 'text-rose-600' : 'text-blue-600'
            }`}
          >
            {student.progressPercent}%
          </span>
        </div>
        <ProgressBar
          value={student.progressPercent}
          color={isAlert ? 'rose' : student.progressPercent > 80 ? 'emerald' : 'blue'}
          size="xs"
        />
      </div>
    </div>
  );
};
