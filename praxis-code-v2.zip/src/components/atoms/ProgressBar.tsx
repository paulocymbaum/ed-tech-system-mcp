import React from 'react';

export interface ProgressBarProps {
  value: number; // 0 to 100
  max?: number;
  color?: 'emerald' | 'blue' | 'amber' | 'indigo' | 'purple' | 'rose';
  size?: 'xs' | 'sm' | 'md';
  className?: string;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  value,
  max = 100,
  color = 'emerald',
  size = 'sm',
  className = '',
}) => {
  const percentage = Math.min(100, Math.max(0, (value / max) * 100));

  const sizeClasses = {
    xs: 'h-1.5',
    sm: 'h-2',
    md: 'h-3',
  };

  const colorClasses = {
    emerald: 'bg-emerald-500',
    blue: 'bg-blue-600',
    amber: 'bg-amber-500',
    indigo: 'bg-indigo-600',
    purple: 'bg-purple-600',
    rose: 'bg-rose-500',
  };

  return (
    <div className={`w-full bg-slate-100 rounded-full overflow-hidden ${sizeClasses[size]} ${className}`}>
      <div
        className={`${colorClasses[color]} h-full rounded-full transition-all duration-500 ease-out`}
        style={{ width: `${percentage}%` }}
      />
    </div>
  );
};
