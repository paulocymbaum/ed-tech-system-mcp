import React from 'react';

export interface TabPillProps {
  label: string;
  active: boolean;
  onClick: () => void;
  icon?: React.ReactNode;
  count?: number | string;
  badge?: string;
  activeColor?: 'blue' | 'white' | 'primary';
}

export const TabPill: React.FC<TabPillProps> = ({
  label,
  active,
  onClick,
  icon,
  count,
  badge,
  activeColor = 'blue',
}) => {
  const activeClass =
    activeColor === 'white'
      ? 'bg-white text-blue-700 shadow-sm font-bold'
      : 'bg-blue-600 text-white font-semibold shadow-sm';

  const inactiveClass = 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50';

  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl text-xs transition-all select-none cursor-pointer ${
        active ? activeClass : inactiveClass
      }`}
    >
      {icon && <span className="shrink-0">{icon}</span>}
      <span>{label}</span>
      {count !== undefined && (
        <span
          className={`text-[10px] px-1.5 py-0.2 rounded-full ${
            active ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
          }`}
        >
          {count}
        </span>
      )}
      {badge && (
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse ml-0.5" />
      )}
    </button>
  );
};
