import React from 'react';

export interface AvatarProps {
  initials: string;
  name?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  bgGradient?: string;
  isOnline?: boolean;
  statusBadge?: string;
  className?: string;
}

export const Avatar: React.FC<AvatarProps> = ({
  initials,
  size = 'md',
  bgGradient = 'from-blue-600 to-indigo-600',
  isOnline = false,
  statusBadge,
  className = '',
}) => {
  const sizeClasses = {
    sm: 'w-7 h-7 text-[11px]',
    md: 'w-9 h-9 text-xs',
    lg: 'w-11 h-11 text-sm',
    xl: 'w-14 h-14 text-base',
  };

  return (
    <div className={`relative inline-flex shrink-0 ${className}`}>
      <div
        className={`${sizeClasses[size]} rounded-full bg-gradient-to-tr ${bgGradient} text-white font-bold flex items-center justify-center shadow-xs border border-white/20`}
      >
        {initials}
      </div>
      {isOnline && (
        <span className="absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-white" />
      )}
      {statusBadge && (
        <span className="absolute -top-1 -right-1 px-1.5 py-0.2 rounded-full bg-red-500 text-white text-[9px] font-bold ring-2 ring-white">
          {statusBadge}
        </span>
      )}
    </div>
  );
};
