import React from 'react';

export interface BadgeProps {
  children: React.ReactNode;
  variant?: 'completed' | 'in-progress' | 'not-started' | 'fire' | 'info' | 'neutral' | 'score' | 'danger';
  size?: 'sm' | 'md';
  dot?: boolean;
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  size = 'md',
  dot = false,
  className = '',
}) => {
  const sizeClasses = {
    sm: 'text-[10px] px-2 py-0.5',
    md: 'text-xs px-2.5 py-0.5',
  };

  const variantClasses = {
    completed: 'bg-emerald-50 text-emerald-700 border border-emerald-200/80',
    'in-progress': 'bg-amber-50 text-amber-700 border border-amber-200/80',
    'not-started': 'bg-slate-100 text-slate-600 border border-slate-200',
    fire: 'bg-amber-400/20 text-amber-200 border border-amber-300/30',
    info: 'bg-blue-50 text-blue-700 border border-blue-200/70',
    neutral: 'bg-slate-100 text-slate-700 border border-slate-200',
    score: 'bg-emerald-50 text-emerald-700 font-bold border border-emerald-200',
    danger: 'bg-rose-50 text-rose-700 border border-rose-200',
  };

  const dotColor = {
    completed: 'bg-emerald-500',
    'in-progress': 'bg-amber-500 animate-pulse',
    'not-started': 'bg-slate-400',
    fire: 'bg-amber-400',
    info: 'bg-blue-500',
    neutral: 'bg-slate-500',
    score: 'bg-emerald-500',
    danger: 'bg-rose-500',
  };

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-semibold rounded-full select-none ${sizeClasses[size]} ${variantClasses[variant]} ${className}`}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${dotColor[variant]}`} />}
      {children}
    </span>
  );
};
