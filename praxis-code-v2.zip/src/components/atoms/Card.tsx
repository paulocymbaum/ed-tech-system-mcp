import React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  variant?: 'default' | 'elevated' | 'tinted' | 'dark' | 'gradient';
  hoverEffect?: boolean;
  className?: string;
}

export const Card: React.FC<CardProps> = ({
  children,
  variant = 'default',
  hoverEffect = false,
  className = '',
  ...props
}) => {
  const variantClasses = {
    default: 'bg-white border border-slate-200/90 shadow-xs',
    elevated: 'bg-white border border-slate-200/80 shadow-md',
    tinted: 'bg-slate-50/70 border border-slate-200/70',
    dark: 'bg-[#090b10] text-slate-100 border border-slate-800',
    gradient: 'bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 text-white shadow-xl shadow-blue-900/10',
  };

  const hoverClasses = hoverEffect
    ? 'card-transition hover:shadow-md hover:-translate-y-0.5'
    : '';

  return (
    <div
      className={`rounded-3xl p-5 ${variantClasses[variant]} ${hoverClasses} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
};
