import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { LiveCodeEditor } from './LiveCodeEditor';
import { ChecklistItem } from '../molecules/ChecklistItem';
import { QuizOptionCard } from '../molecules/QuizOptionCard';
import {
  X,
  Maximize2,
  Minimize2,
  Award,
  Sparkles,
  Scissors,
  Pencil,
  FileSpreadsheet,
  Upload,
  FileDown,
  CheckCircle2,
  Code2,
  Cpu,
  BookOpen,
  Terminal,
  HelpCircle,
  RotateCcw,
} from 'lucide-react';
import { Button } from '../atoms/Button';

export const WorkspaceModal: React.FC = () => {
  const {
    workspaceModal,
    closeWorkspaceModal,
    setWorkspaceModalMode,
    lessons,
    updateLessonProgress,
    showToast,
  } = useApp();

  const { isOpen, mode, lessonId } = workspaceModal;
  const currentLesson = lessons.find((l) => l.id === lessonId) || lessons[1]; // fallback to lesson-2

  // Close on Escape key press
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        closeWorkspaceModal();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, closeWorkspaceModal]);

  // Project checklist state
  const [checklist, setChecklist] = useState({
    step1: true,
    step2: false,
    step3: false,
    step4: false,
  });

  const [uploadedPhoto, setUploadedPhoto] = useState<string | null>(null);

  // Quiz state
  const [selectedQ1, setSelectedQ1] = useState<'A' | 'B' | null>('A');
  const [selectedQ2, setSelectedQ2] = useState<string>('0.75');
  const [selectedQ3, setSelectedQ3] = useState<string>('ZeroDivisionError');
  const [quizScoreBadge, setQuizScoreBadge] = useState<string | null>(null);

  if (!isOpen) return null;

  const toggleChecklist = (step: 'step1' | 'step2' | 'step3' | 'step4') => {
    setChecklist((prev) => {
      const next = { ...prev, [step]: !prev[step] };
      const completedSteps = Object.values(next).filter(Boolean).length;
      updateLessonProgress(currentLesson.id, { tasksCompleted: completedSteps });
      return next;
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const previewUrl = URL.createObjectURL(file);
      setUploadedPhoto(previewUrl);
      showToast(`Foto do protótipo maker "${file.name}" carregada no modal!`);
      if (!checklist.step4) {
        toggleChecklist('step4');
      }
    }
  };

  const handleCheckQuiz = () => {
    setQuizScoreBadge('3/3 Acertos (100%) ⭐ - Excelente raciocínio algorítmico!');
    showToast('Quiz concluído no Modal 90%! Pontuação máxima registrada.');
  };

  const handleResetQuiz = () => {
    setQuizScoreBadge(null);
    setSelectedQ1(null);
    setSelectedQ2('');
    setSelectedQ3('');
    showToast('Quiz resetado para nova tentativa.');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6 animate-in fade-in zoom-in-95 duration-200 select-none"
    >
      {/* 90% Screen Container */}
      <div className="w-[90vw] h-[90vh] max-w-[1550px] max-h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-slate-200/90 relative">
        {/* Modal Top Header Bar */}
        <header className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center space-x-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shrink-0 shadow-xs">
              {mode === 'quiz' ? (
                <Award className="w-5 h-5" />
              ) : mode === 'project' ? (
                <Cpu className="w-5 h-5" />
              ) : (
                <Terminal className="w-5 h-5" />
              )}
            </div>
            <div className="min-w-0">
              <div className="flex items-center space-x-2">
                <h2 className="text-sm sm:text-base font-bold text-white truncate tracking-tight">
                  {currentLesson.title}
                </h2>
                <span className="hidden sm:inline-flex px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30 text-[10px] font-bold uppercase tracking-wider">
                  Modo Foco 90% da Tela
                </span>
              </div>
              <p className="text-[11px] text-slate-400 truncate">
                {mode === 'quiz'
                  ? 'Questionário de Verificação de Sintaxe, Lógica & Aritmética de Ponto Flutuante'
                  : mode === 'project'
                  ? 'Laboratório Maker & Protótipo Físico com Sensores de Ângulo'
                  : 'Ambiente Expandido de Live Coding em Python e JavaScript'}
              </p>
            </div>
          </div>

          {/* Center Tabs: Switch between Quiz, Project and Live Coding */}
          <div className="hidden md:flex items-center bg-slate-800 p-1 rounded-2xl border border-slate-700/80">
            <button
              type="button"
              onClick={() => setWorkspaceModalMode('quiz')}
              className={`flex items-center space-x-2 py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                mode === 'quiz'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              <span>Logic Quiz</span>
            </button>

            <button
              type="button"
              onClick={() => setWorkspaceModalMode('project')}
              className={`flex items-center space-x-2 py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                mode === 'project'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>Hardware Maker</span>
            </button>

            <button
              type="button"
              onClick={() => setWorkspaceModalMode('coding')}
              className={`flex items-center space-x-2 py-1.5 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                mode === 'coding'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Code2 className="w-3.5 h-3.5" />
              <span>Live Coding</span>
            </button>
          </div>

          {/* Right Action & Close Button */}
          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={closeWorkspaceModal}
              title="Fechar Modal (Esc)"
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* Mobile Tab Switcher */}
        <div className="flex md:hidden items-center bg-slate-100 p-2 border-b border-slate-200">
          <button
            type="button"
            onClick={() => setWorkspaceModalMode('quiz')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg text-center ${
              mode === 'quiz' ? 'bg-blue-600 text-white' : 'text-slate-600'
            }`}
          >
            Quiz
          </button>
          <button
            type="button"
            onClick={() => setWorkspaceModalMode('project')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg text-center ${
              mode === 'project' ? 'bg-blue-600 text-white' : 'text-slate-600'
            }`}
          >
            Maker
          </button>
          <button
            type="button"
            onClick={() => setWorkspaceModalMode('coding')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg text-center ${
              mode === 'coding' ? 'bg-blue-600 text-white' : 'text-slate-600'
            }`}
          >
            Coding
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 lg:p-8 bg-slate-50/50">
          {/* ======================================================== */}
          {/* MODE 1: QUIZ MODAL                                       */}
          {/* ======================================================== */}
          {mode === 'quiz' && (
            <div className="max-w-4xl mx-auto space-y-6">
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs space-y-6">
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
                      Algorithmic Verification
                    </span>
                    <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                      Quiz de Lógica Computacional &amp; Geometria em Código
                    </h3>
                  </div>
                  <span className="text-xs font-bold px-3 py-1 bg-blue-50 text-blue-700 rounded-full border border-blue-200">
                    3 Questões Interativas
                  </span>
                </div>

                {/* Question 1: Visual Canvas Multi-Choice */}
                <div className="space-y-3 p-4 rounded-2xl bg-slate-50/70 border border-slate-200/60">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      Questão 1 de 3 • Renderização Angular
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded">
                      Canvas 2D
                    </span>
                  </div>
                  <p className="text-sm font-bold text-slate-800">
                    Qual representação gráfica corresponde exatamente ao resultado da fórmula de fatia angular{' '}
                    <code className="text-blue-600 font-mono bg-white px-2 py-0.5 rounded border border-blue-200 text-xs">
                      (360 / 4) * 3 = 270°
                    </code>{' '}
                    (3 partes de 4 do círculo)?
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <QuizOptionCard
                      id="modal-opt-a"
                      label="Opção A: Ângulo de 270° (3 fatias ativas)"
                      fractionVisual={{ total: 4, filled: 3 }}
                      isSelected={selectedQ1 === 'A'}
                      onSelect={() => setSelectedQ1('A')}
                    />
                    <QuizOptionCard
                      id="modal-opt-b"
                      label="Opção B: Ângulo de 90° (1 fatia ativa)"
                      fractionVisual={{ total: 4, filled: 1 }}
                      isSelected={selectedQ1 === 'B'}
                      onSelect={() => setSelectedQ1('B')}
                    />
                  </div>
                </div>

                {/* Question 2: Python Code Problem */}
                <div className="space-y-3 p-4 rounded-2xl bg-slate-50/70 border border-slate-200/60">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      Questão 2 de 3 • Avaliação de Expressão em Python
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-purple-100 text-purple-800 rounded">
                      Python 3
                    </span>
                  </div>
                  <p className="text-sm font-bold text-slate-800">
                    Considere o trecho de código abaixo que calcula a proporção de fatias consumidas:
                  </p>

                  <div className="bg-[#0f172a] rounded-xl p-3.5 font-mono text-xs text-slate-200 border border-slate-800">
                    <span className="text-slate-400"># Array de fatias (1 = consumida, 0 = restante)</span><br />
                    slices = [1, 1, 1, 0]<br />
                    resultado = sum(slices) / len(slices)<br />
                    <span className="text-tertiary-fixed">print</span>(resultado)
                  </div>

                  <p className="text-xs text-slate-600 font-medium">Qual valor será impresso no console?</p>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-semibold pt-1">
                    {['0.25', '0.75', '3.0', '1.0'].map((opt) => (
                      <label
                        key={opt}
                        onClick={() => setSelectedQ2(opt)}
                        className={`flex items-center justify-center p-3 rounded-xl cursor-pointer border transition text-center ${
                          selectedQ2 === opt
                            ? 'bg-blue-50 border-blue-400 text-blue-900 font-bold shadow-xs'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <input
                          type="radio"
                          name="modal-q2"
                          checked={selectedQ2 === opt}
                          onChange={() => setSelectedQ2(opt)}
                          className="hidden"
                        />
                        <span>{opt} {opt === '0.75' && '(3/4)'}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Question 3: Exception Handling */}
                <div className="space-y-3 p-4 rounded-2xl bg-slate-50/70 border border-slate-200/60">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      Questão 3 de 3 • Programação Defensiva &amp; Exceções
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-100 text-amber-800 rounded">
                      Error Handling
                    </span>
                  </div>
                  <p className="text-sm font-bold text-slate-800">
                    O que acontece em Python se uma função tentar calcular{' '}
                    <code className="font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200 text-rose-600">
                      fatia = 3 / 0
                    </code>{' '}
                    sem uma cláusula condicional de proteção?
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs font-semibold pt-1">
                    {[
                      { val: 'ZeroDivisionError', desc: 'Gera a exceção ZeroDivisionError e interrompe o programa' },
                      { val: 'Retorna 0', desc: 'Retorna o valor 0 automaticamente sem avisos' },
                      { val: 'Infinito', desc: 'Gera valor float infinito (inf) sem interrupção' },
                      { val: 'None', desc: 'Retorna None e limpa a memória do terminal' },
                    ].map((opt) => (
                      <label
                        key={opt.val}
                        onClick={() => setSelectedQ3(opt.val)}
                        className={`flex items-start space-x-2.5 p-3 rounded-xl cursor-pointer border transition ${
                          selectedQ3 === opt.val
                            ? 'bg-blue-50 border-blue-400 text-blue-900 font-bold shadow-xs'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <input
                          type="radio"
                          name="modal-q3"
                          checked={selectedQ3 === opt.val}
                          onChange={() => setSelectedQ3(opt.val)}
                          className="mt-0.5 text-blue-600"
                        />
                        <div>
                          <span className="font-bold">{opt.val}</span>
                          <p className="text-[11px] font-normal text-slate-500 mt-0.5 leading-snug">
                            {opt.desc}
                          </p>
                        </div>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Score & Submission Banner */}
                {quizScoreBadge ? (
                  <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center space-y-2 animate-in zoom-in-95 duration-200">
                    <p className="text-sm font-extrabold text-emerald-800">{quizScoreBadge}</p>
                    <p className="text-xs text-emerald-700">
                      Suas respostas demonstraram compreensão de frações, listas e tratamento de exceções.
                    </p>
                    <div className="flex items-center justify-center space-x-3 pt-2">
                      <Button variant="secondary" size="sm" onClick={handleResetQuiz} icon={<RotateCcw className="w-3.5 h-3.5" />}>
                        Tentar Novamente
                      </Button>
                      <Button variant="success" size="sm" onClick={closeWorkspaceModal} icon={<CheckCircle2 className="w-3.5 h-3.5" />}>
                        Salvar e Concluir
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-end space-x-3 pt-2 border-t border-slate-100">
                    <Button variant="secondary" size="md" onClick={closeWorkspaceModal}>
                      Cancelar
                    </Button>
                    <Button variant="primary" size="md" onClick={handleCheckQuiz} icon={<Award className="w-4 h-4" />}>
                      Avaliar Respostas &amp; Emitir Nota
                    </Button>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* MODE 2: PROJECT MODAL (HARDWARE / MAKER)                 */}
          {/* ======================================================== */}
          {mode === 'project' && (
            <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: Instructions & Step Checklist (6 cols) */}
              <div className="lg:col-span-6 bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-5">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-blue-600">
                      Maker &amp; Hardware Lab
                    </span>
                    <span className="text-xs font-bold bg-emerald-50 text-emerald-700 px-3 py-0.5 rounded-full border border-emerald-200">
                      {Object.values(checklist).filter(Boolean).length} de 4 Etapas Concluídas
                    </span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mt-1">
                    Sensor Angular de Fatias &amp; Protótipo Físico
                  </h3>
                  <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                    Neste projeto prático, você criará um disco angular físico para calibrar sensores e
                    conectar as fatias geométricas às variáveis do seu programa em Python.
                  </p>
                </div>

                {/* Required Materials */}
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/60">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                    Materiais Necessários
                  </span>
                  <div className="flex items-center space-x-4 text-xs font-semibold text-slate-700 flex-wrap gap-2">
                    <span className="flex items-center gap-1.5">
                      <Scissors className="w-3.5 h-3.5 text-blue-600" /> Tesoura
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Pencil className="w-3.5 h-3.5 text-amber-600" /> Transferidor
                    </span>
                    <span className="flex items-center gap-1.5">
                      <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" /> Prato de Papelão
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Cpu className="w-3.5 h-3.5 text-purple-600" /> Placa Micro:bit (Opcional)
                    </span>
                  </div>
                </div>

                {/* Steps Checklist */}
                <div className="space-y-2.5">
                  <span className="text-xs font-bold text-slate-800">Instruções Passo a Passo:</span>
                  <ChecklistItem
                    id="modal-step-1"
                    stepNumber={1}
                    title="Baixar gabarito de ângulos radianos"
                    subtitle="Arquivo vetorial com divisões em 90°, 180°, 270° e 360°."
                    isChecked={checklist.step1}
                    onToggle={() => toggleChecklist('step1')}
                  />
                  <ChecklistItem
                    id="modal-step-2"
                    stepNumber={2}
                    title="Colorir 3/4 fatias em vermelho (270°)"
                    subtitle="Identifique o ângulo angular equivalente à fração 3/4."
                    isChecked={checklist.step2}
                    onToggle={() => toggleChecklist('step2')}
                  />
                  <ChecklistItem
                    id="modal-step-3"
                    stepNumber={3}
                    title="Rotular índices do array [0, 1, 2] nas fatias"
                    subtitle="Escreva os índices numéricos que o loop for em Python itera."
                    isChecked={checklist.step3}
                    onToggle={() => toggleChecklist('step3')}
                  />
                  <ChecklistItem
                    id="modal-step-4"
                    stepNumber={4}
                    title="Fotografar protótipo para submissão com IA"
                    subtitle="A visão computacional avaliará o alinhamento angular e a proporcionalidade."
                    isChecked={checklist.step4}
                    onToggle={() => toggleChecklist('step4')}
                  />
                </div>
              </div>

              {/* Right Column: Submission & Blueprint Preview (6 cols) */}
              <div className="lg:col-span-6 bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-5">
                <h4 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                  <Upload className="w-4 h-4 text-blue-600" />
                  <span>Área de Envio do Protótipo &amp; Validação</span>
                </h4>

                {/* File Upload Dropzone */}
                <label className="p-6 rounded-2xl bg-slate-50 border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-blue-50/50 hover:border-blue-400 transition block">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  {uploadedPhoto ? (
                    <div className="space-y-3 text-center">
                      <img
                        src={uploadedPhoto}
                        alt="Preview do protótipo"
                        className="w-40 h-40 object-cover rounded-2xl mx-auto shadow-md border border-slate-200"
                      />
                      <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Foto Carregada com Sucesso</span>
                      </div>
                      <p className="text-[11px] text-slate-400">Clique para substituir imagem</p>
                    </div>
                  ) : (
                    <>
                      <div className="w-14 h-14 rounded-2xl bg-blue-100 text-blue-600 flex items-center justify-center mb-3 mx-auto shadow-2xs">
                        <Upload className="w-7 h-7" />
                      </div>
                      <p className="text-sm font-bold text-slate-900">Upload da Foto do Protótipo</p>
                      <p className="text-xs text-slate-500 mt-1">
                        PNG, JPG até 10MB (Arraste ou clique para selecionar)
                      </p>
                      <span className="mt-3 inline-block px-3 py-1 bg-white rounded-lg border border-slate-200 text-xs text-slate-700 font-semibold shadow-2xs">
                        Procurar no computador
                      </span>
                    </>
                  )}
                </label>

                {/* Template Download */}
                <button
                  type="button"
                  onClick={() => showToast('Download do gabarito de corte "template_angles.pdf" iniciado')}
                  className="w-full flex items-center justify-center space-x-2 py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition cursor-pointer border border-slate-200"
                >
                  <FileDown className="w-4 h-4 text-slate-600" />
                  <span>Baixar Gabarito Imprimível (PDF de 90° a 360°)</span>
                </button>

                <div className="p-4 bg-blue-50/70 border border-blue-200 rounded-2xl text-xs text-blue-900 space-y-1">
                  <p className="font-bold flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                    Como a Visão Computacional Avalia:
                  </p>
                  <p className="text-[11px] text-blue-800 leading-relaxed">
                    Nossa IA detecta as divisões radiais desenhadas no papelão, valida se a proporção de 270°
                    foi preservada e sincroniza a nota diretamente com a fila pedagógica do professor.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ======================================================== */}
          {/* MODE 3: LIVE CODING MODAL                                */}
          {/* ======================================================== */}
          {mode === 'coding' && (
            <div className="max-w-4xl mx-auto space-y-4">
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/80 shadow-xs">
                <LiveCodeEditor />
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer Bar */}
        <footer className="px-6 py-3.5 bg-white border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center space-x-2 text-xs text-slate-500 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Sincronização em tempo real com o perfil de Jane Cooper</span>
          </div>

          <div className="flex items-center space-x-2.5">
            <Button variant="secondary" size="sm" onClick={closeWorkspaceModal}>
              Minimizar
            </Button>
            <Button
              variant="primary"
              size="sm"
              onClick={() => {
                showToast('Progresso salvo e submetido com sucesso!');
                closeWorkspaceModal();
              }}
              icon={<CheckCircle2 className="w-4 h-4" />}
            >
              Concluir Atividade
            </Button>
          </div>
        </footer>
      </div>
    </div>
  );
};
