import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Sparkles, BookPlus } from 'lucide-react';
import { Button } from '../atoms/Button';

export interface CreateLessonModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CreateLessonModal: React.FC<CreateLessonModalProps> = ({ isOpen, onClose }) => {
  const { addLesson } = useApp();
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('Matemática Aplicada & Live Coding');
  const [day, setDay] = useState('Segunda-feira');
  const [duration, setDuration] = useState('45');
  const [description, setDescription] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    addLesson({
      title: title.trim(),
      subtitle: `${day} • Prática Pedagógica`,
      subject,
      day,
      durationMins: parseInt(duration, 10) || 45,
      description: description.trim() || 'Nova atividade criada pelo professor.',
    });

    setTitle('');
    setDescription('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
              <BookPlus className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Criar Nova Lição / Atividade</h3>
              <p className="text-xs text-slate-400">Atribua conteúdo para os estudantes da turma</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs font-semibold">
          <div>
            <label className="block text-slate-700 mb-1">Título da Lição</label>
            <input
              type="text"
              required
              placeholder="Ex: Lesson 6: Raciocínio Lógico & Geometria 3D"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none text-slate-800 font-normal"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 mb-1">Área / Disciplina</label>
              <select
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 outline-none text-slate-800 font-normal bg-white"
              >
                <option value="Matemática Aplicada & Live Coding">Matemática &amp; Live Coding</option>
                <option value="Língua Portuguesa & Alfabetização">Língua Portuguesa</option>
                <option value="Pensamento Computacional & Lógica">Ciência da Computação</option>
                <option value="Ciências & Metodologia Científica">Ciências &amp; Natureza</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-700 mb-1">Dia da Semana</label>
              <select
                value={day}
                onChange={(e) => setDay(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 outline-none text-slate-800 font-normal bg-white"
              >
                <option value="Segunda-feira">Segunda-feira</option>
                <option value="Terça-feira">Terça-feira</option>
                <option value="Quarta-feira">Quarta-feira</option>
                <option value="Quinta-feira">Quinta-feira</option>
                <option value="Sexta-feira">Sexta-feira</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-slate-700 mb-1">Descrição / Objetivos de Aprendizagem</label>
            <textarea
              rows={3}
              placeholder="Descreva as tarefas práticas e habilidades BNCC que o aluno desenvolverá..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-blue-500 outline-none text-slate-800 font-normal resize-none"
            />
          </div>

          <div className="flex items-center justify-end space-x-2 pt-2 border-t border-slate-100">
            <Button variant="secondary" size="md" type="button" onClick={onClose}>
              Cancelar
            </Button>
            <Button variant="primary" size="md" type="submit">
              Publicar Lição
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
