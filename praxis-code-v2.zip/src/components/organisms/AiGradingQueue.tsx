import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  Sparkles,
  CheckCircle2,
  CheckCheck,
  Eye,
  MessageSquare,
  Camera,
  Bot,
  Compass,
  Maximize2,
} from 'lucide-react';
import { ASSETS } from '../../constants/assets';

export const AiGradingQueue: React.FC = () => {
  const {
    submissions,
    approveSubmission,
    approveAllAiSubmissions,
    showToast,
    openWorkspaceModal,
  } = useApp();
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'live-coding' | 'quizzes' | 'manual'>(
    'all'
  );

  const filteredSubmissions = submissions.filter((sub) => {
    if (selectedFilter === 'live-coding') return sub.type === 'live-coding';
    if (selectedFilter === 'quizzes') return sub.type === 'quiz';
    if (selectedFilter === 'manual') return sub.type === 'manual-project';
    return true;
  });

  return (
    <section className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-5">
      {/* Header & Approve All CTA */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center space-x-2.5">
          <h2 className="text-lg font-bold text-slate-900 tracking-tight">
            Fila de Correção &amp; Avaliação com IA
          </h2>
          <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-xs font-bold">
            12 aguardando
          </span>
        </div>

        <button
          type="button"
          onClick={approveAllAiSubmissions}
          className="text-blue-600 hover:text-blue-700 font-semibold text-xs flex items-center gap-1.5 transition-colors cursor-pointer self-start sm:self-auto py-1 px-2 rounded-lg hover:bg-blue-50"
        >
          <CheckCheck className="w-4 h-4 text-blue-600" />
          <span>Aprovar Todas IA</span>
        </button>
      </div>

      {/* Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-nowrap">
        <button
          type="button"
          onClick={() => setSelectedFilter('all')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
            selectedFilter === 'all'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Todas (12)
        </button>
        <button
          type="button"
          onClick={() => setSelectedFilter('live-coding')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
            selectedFilter === 'live-coding'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Projetos de Live Coding (5)
        </button>
        <button
          type="button"
          onClick={() => setSelectedFilter('quizzes')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
            selectedFilter === 'quizzes'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Quizzes (4)
        </button>
        <button
          type="button"
          onClick={() => setSelectedFilter('manual')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all cursor-pointer ${
            selectedFilter === 'manual'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          Práticas Manuais (3)
        </button>
      </div>

      {/* List of submissions */}
      <div className="space-y-4">
        {filteredSubmissions.map((sub) => {
          const isApproved = sub.status === 'approved';

          return (
            <div
              key={sub.id}
              className={`rounded-2xl p-4.5 border transition-all duration-200 space-y-3.5 ${
                isApproved
                  ? 'bg-emerald-50/50 border-emerald-200 opacity-90'
                  : 'bg-slate-50/70 border-slate-200/80 hover:bg-slate-100/60'
              }`}
            >
              {/* Header row */}
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                    {sub.studentInitials}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-slate-900">{sub.studentName}</span>
                      <span className="px-1.5 py-0.2 rounded bg-slate-200 text-slate-600 text-[10px] font-medium">
                        {sub.studentGrade}
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400">
                      {sub.submittedAt} •{' '}
                      {sub.type === 'live-coding'
                        ? 'Python Live Coding'
                        : sub.type === 'manual-project'
                        ? 'Prática Manual'
                        : 'Quiz Conceitual'}
                    </span>
                  </div>
                </div>

                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100/80 text-blue-800 text-xs font-bold">
                  <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                  <span>
                    Nota Sugerida IA: {sub.suggestedScore.toFixed(1)} / 10
                  </span>
                </div>
              </div>

              {/* Title */}
              <div className="font-bold text-xs text-slate-900">{sub.lessonTitle}</div>

              {/* Live coding code preview */}
              {sub.codeSnippet && (
                <div className="bg-[#0f172a] rounded-xl p-3 font-mono text-[11px] text-slate-200 overflow-x-auto leading-relaxed border border-slate-800">
                  <pre className="m-0 font-mono text-slate-200">{sub.codeSnippet}</pre>
                </div>
              )}

              {/* Manual image attachment & Computer Vision info */}
              {sub.imageAttachment && (
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-center">
                  <div className="sm:col-span-1 relative rounded-xl overflow-hidden h-20 bg-slate-900 flex items-center justify-center border border-slate-200">
                    <img
                      src={sub.imageAttachment}
                      alt="Submissão do aluno"
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-black/80 text-white font-medium text-[9px] flex items-center gap-1">
                      <Camera className="w-3 h-3" /> 1 Foto
                    </span>
                  </div>

                  <div className="sm:col-span-3 p-3 rounded-xl bg-white border border-slate-200/80 flex items-start gap-2.5 h-full">
                    <Compass className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <p className="text-[11px] text-slate-600 leading-snug">
                      <strong className="text-slate-900 font-bold">Visão Computacional:</strong>{' '}
                      {sub.computerVisionNote}
                    </p>
                  </div>
                </div>
              )}

              {/* AI assessment feedback box */}
              <div className="p-3 rounded-xl bg-white border border-slate-200/80 flex items-start gap-2.5">
                <Bot className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <p className="text-[11px] text-slate-600 leading-snug">
                  <strong className="text-slate-900 font-bold">Avaliação IA:</strong>{' '}
                  {sub.aiFeedbackSummary}
                </p>
              </div>

              {/* Action buttons */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => approveSubmission(sub.id)}
                    disabled={isApproved}
                    className={`px-3.5 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer ${
                      isApproved
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {isApproved
                        ? 'Nota Aprovada ✓'
                        : `Aprovar Nota IA (${sub.suggestedScore.toFixed(1)})`}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      openWorkspaceModal(
                        sub.type === 'quiz' ? 'quiz' : sub.type === 'manual-project' ? 'project' : 'coding',
                        sub.lessonId
                      )
                    }
                    title="Inspecionar atividade em Modal Centralizado (90% da tela)"
                    className="px-3 py-1.5 rounded-xl bg-blue-50 border border-blue-200 text-blue-700 hover:bg-blue-100 text-xs font-bold transition cursor-pointer flex items-center gap-1 shadow-2xs"
                  >
                    <Maximize2 className="w-3.5 h-3.5 text-blue-600" />
                    <span>Inspecionar (90%)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => showToast(`Abrindo rubrica detalhada da lição`)}
                    className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 text-xs font-semibold transition cursor-pointer flex items-center gap-1"
                  >
                    <Eye className="w-3.5 h-3.5 text-slate-500" />
                    <span>Ver Rubrica</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => showToast(`Enviando mensagem direta para ${sub.studentName}`)}
                  className="text-slate-500 hover:text-blue-600 text-xs font-semibold flex items-center gap-1 transition cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>Dar Feedback</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
