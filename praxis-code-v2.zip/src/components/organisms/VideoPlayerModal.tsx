import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Play, Pause, Volume2, Maximize, RotateCcw } from 'lucide-react';

export const VideoPlayerModal: React.FC = () => {
  const { activeVideoModal, setActiveVideoModal } = useApp();
  const [isPlaying, setIsPlaying] = useState(true);

  if (!activeVideoModal) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl border border-slate-700/30">
        {/* Header Bar */}
        <div className="p-4 bg-slate-950 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center space-x-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block animate-pulse" />
            <span className="font-bold text-sm tracking-tight">{activeVideoModal.title}</span>
          </div>
          <button
            type="button"
            onClick={() => setActiveVideoModal(null)}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Canvas Stage */}
        <div className="aspect-video bg-black flex items-center justify-center relative overflow-hidden group select-none">
          {/* Animated Mathematical / Algorithmic backdrop */}
          <div className="absolute inset-0 bg-gradient-to-tr from-slate-950 via-slate-900 to-blue-950 flex flex-col items-center justify-center p-6 text-center">
            {activeVideoModal.embedFormula && (
              <div className="text-blue-400/30 font-mono text-3xl font-extrabold mb-4 tracking-widest">
                {activeVideoModal.embedFormula}
              </div>
            )}
            <div
              onClick={() => setIsPlaying(!isPlaying)}
              className="w-16 h-16 rounded-full bg-red-600/90 hover:bg-red-500 text-white flex items-center justify-center shadow-xl transition-transform hover:scale-105 cursor-pointer mb-3"
            >
              {isPlaying ? (
                <Pause className="w-7 h-7 fill-current" />
              ) : (
                <Play className="w-7 h-7 fill-current ml-1" />
              )}
            </div>
            <p className="text-white text-sm font-semibold">
              {isPlaying ? 'Reproduzindo aula demonstrativa interativa' : 'Vídeo Pausado'}
            </p>
            <p className="text-slate-400 text-xs mt-1">{activeVideoModal.channel}</p>
          </div>

          {/* Bottom video control bar */}
          <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/90 to-transparent flex items-center justify-between text-white text-xs">
            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={() => setIsPlaying(!isPlaying)}
                className="hover:text-blue-400 transition cursor-pointer"
              >
                {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
              </button>
              <span className="font-mono text-[11px] text-slate-300">03:42 / {activeVideoModal.duration}</span>
            </div>
            <div className="flex items-center space-x-3">
              <Volume2 className="w-4 h-4 cursor-pointer hover:text-blue-400" />
              <Maximize className="w-4 h-4 cursor-pointer hover:text-blue-400" />
            </div>
          </div>
        </div>

        {/* Footer info bar */}
        <div className="p-4 bg-slate-50 flex items-center justify-between text-xs text-slate-600 border-t border-slate-200">
          <div className="flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Reprodução em 1080p • Legendado em Português (Brasil)</span>
          </div>
          <button
            type="button"
            onClick={() => setActiveVideoModal(null)}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 font-bold rounded-xl text-slate-800 transition cursor-pointer"
          >
            Fechar Vídeo
          </button>
        </div>
      </div>
    </div>
  );
};
