import React from 'react';
import {
  LayoutDashboard,
  CalendarDays,
  BookOpen,
  FolderOpen,
  Users,
  Settings,
  HelpCircle,
  LogOut,
  Sparkles,
  Menu,
  CheckSquare,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { NavigationPath } from '../../types';
import { ASSETS } from '../../constants/assets';
import { RoleSwitcher } from '../molecules/RoleSwitcher';

export const Sidebar: React.FC = () => {
  const {
    role,
    currentPath,
    setCurrentPath,
    isSidebarCollapsed,
    toggleSidebar,
    showToast,
  } = useApp();

  const handleNavClick = (path: NavigationPath) => {
    setCurrentPath(path);
  };

  const navItems = [
    {
      id: 'dashboard' as NavigationPath,
      label: 'Dashboard',
      icon: <LayoutDashboard className="w-5 h-5 shrink-0" />,
    },
    {
      id: 'weekly-plan' as NavigationPath,
      label: 'Weekly Plan',
      icon: <CalendarDays className="w-5 h-5 shrink-0" />,
    },
    {
      id: 'lesson-plans' as NavigationPath,
      label: 'Lesson Plans',
      icon: <BookOpen className="w-5 h-5 shrink-0" />,
    },
    {
      id: 'activities' as NavigationPath,
      label: role === 'teacher' ? 'Activities & Assignments' : 'Activities',
      icon: <CheckSquare className="w-5 h-5 shrink-0" />,
    },
    {
      id: 'assessment' as NavigationPath,
      label: role === 'teacher' ? 'Assessment & IA' : 'Assessment',
      icon: <Sparkles className="w-5 h-5 shrink-0" />,
      badge: role === 'teacher' ? '12' : undefined,
      badgeColor: 'bg-rose-500 text-white',
    },
    {
      id: 'resources' as NavigationPath,
      label: role === 'teacher' ? 'Resources & Materials' : 'Resources',
      icon: <FolderOpen className="w-5 h-5 shrink-0" />,
    },
    {
      id: 'my-students' as NavigationPath,
      label: 'My Students',
      icon: <Users className="w-5 h-5 shrink-0" />,
      badge: role === 'teacher' ? '4' : undefined,
      badgeColor: 'bg-slate-700 text-slate-200',
    },
  ];

  return (
    <aside
      className={`${
        isSidebarCollapsed ? 'w-20' : 'w-64'
      } bg-[#090b10] text-slate-300 flex flex-col justify-between shrink-0 transition-all duration-300 z-40 select-none border-r border-slate-800/80 min-h-screen`}
      id="main-sidebar"
    >
      {/* Upper Section */}
      <div className="p-4 space-y-5">
        {/* Brand header & toggle */}
        <div className="flex items-center justify-between px-1 pt-1">
          <div
            onClick={() => setCurrentPath('dashboard')}
            className="flex items-center space-x-2.5 cursor-pointer group"
          >
            <img
              src={ASSETS.logo}
              alt="Praxis Code Logo"
              className="w-8 h-8 rounded-lg object-contain bg-white/10 p-0.5 shadow-sm group-hover:ring-1 group-hover:ring-blue-400 transition"
            />
            {!isSidebarCollapsed && (
              <span className="text-white font-bold text-lg tracking-tight">
                Praxis Code
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={toggleSidebar}
            aria-label="Toggle Sidebar Navigation"
            className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-slate-800/60 transition-colors cursor-pointer"
          >
            <Menu className="w-4 h-4" />
          </button>
        </div>

        {/* Role Switcher Pill Container */}
        {!isSidebarCollapsed && (
          <div className="pt-1">
            <RoleSwitcher />
          </div>
        )}

        {/* Navigation Items */}
        <nav aria-label="Primary Navigation" className="space-y-1.5 pt-1">
          {navItems.map((item) => {
            const isActive = currentPath === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleNavClick(item.id)}
                title={isSidebarCollapsed ? item.label : undefined}
                className={`w-full flex items-center ${
                  isSidebarCollapsed ? 'justify-center px-2' : 'justify-between px-3.5'
                } py-2.5 rounded-xl transition-all duration-150 cursor-pointer ${
                  isActive
                    ? 'bg-blue-600 text-white font-semibold shadow-md shadow-blue-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/50 font-medium'
                }`}
              >
                <div className="flex items-center space-x-3 min-w-0">
                  {item.icon}
                  {!isSidebarCollapsed && (
                    <span className="text-xs truncate">{item.label}</span>
                  )}
                </div>

                {!isSidebarCollapsed && item.badge && (
                  <span
                    className={`text-[10px] font-bold px-1.5 py-0.2 rounded-full ${item.badgeColor}`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Settings & Logout Menu */}
      <div className="p-4 border-t border-slate-800/80 space-y-1">
        <button
          type="button"
          onClick={() => showToast('Configurações do sistema')}
          className={`w-full flex items-center ${
            isSidebarCollapsed ? 'justify-center px-2' : 'space-x-3 px-3.5'
          } py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/50 transition-colors text-xs font-medium cursor-pointer`}
        >
          <Settings className="w-4 h-4 shrink-0" />
          {!isSidebarCollapsed && <span>Settings</span>}
        </button>

        <button
          type="button"
          onClick={() => showToast('Central de ajuda e suporte pedagógico')}
          className={`w-full flex items-center ${
            isSidebarCollapsed ? 'justify-center px-2' : 'space-x-3 px-3.5'
          } py-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/50 transition-colors text-xs font-medium cursor-pointer`}
        >
          <HelpCircle className="w-4 h-4 shrink-0" />
          {!isSidebarCollapsed && <span>Help</span>}
        </button>

        <button
          type="button"
          onClick={() => setCurrentPath('role-select')}
          className={`w-full flex items-center ${
            isSidebarCollapsed ? 'justify-center px-2' : 'space-x-3 px-3.5'
          } py-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors text-xs font-medium cursor-pointer`}
        >
          <LogOut className="w-4 h-4 shrink-0" />
          {!isSidebarCollapsed && <span>Sign Out / Trocar Papel</span>}
        </button>
      </div>
    </aside>
  );
};
