import React from 'react';
import { useApp } from '../../context/AppContext';
import { ILesson } from '../../types';

export const WeeklyActivityKanban: React.FC = () => {
  const { lessons, setCurrentPath, setActiveLessonId } = useApp();

  const handleOpenLesson = (lesson: ILesson) => {
    setActiveLessonId(lesson.id);
    setCurrentPath('lesson-plans');
  };

  const todoLessons = lessons.filter((l) => l.status === 'Not Started');
  const inProgressLessons = lessons.filter((l) => l.status === 'In-Progress');
  const completedLessons = lessons.filter((l) => l.status === 'Completed');

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
      {/* Column 1: To Do */}
      <div className="bg-slate-100/70 p-4.5 rounded-3xl border border-slate-200/80 space-y-3.5">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400" />
            <h3 className="font-bold text-xs text-slate-700 uppercase tracking-wider">
              To Do
            </h3>
          </div>
          <span className="text-xs font-bold bg-white text-slate-600 px-2 py-0.5 rounded-full border border-slate-200">
            {todoLessons.length}
          </span>
        </div>

        <div className="space-y-3">
          {todoLessons.map((lesson) => {
            const progress = (lesson.tasksCompleted / lesson.tasksTotal) * 100;
            return (
              <div
                key={lesson.id}
                onClick={() => handleOpenLesson(lesson)}
                className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3 hover:shadow-md transition-all cursor-pointer hover:border-blue-400 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                    {lesson.title}
                  </span>
                  <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-medium">
                    {lesson.tasksCompleted}/{lesson.tasksTotal}
                  </span>
                </div>
                <p className="text-xs text-slate-600 font-semibold">{lesson.subtitle}</p>
                <div className="text-[11px] text-slate-400 flex justify-between font-medium">
                  <span>04 Scratch Blocks</span>
                  <span>{lesson.durationMins} Mins</span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-slate-300 h-1.5 rounded-full"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Column 2: In Progress */}
      <div className="bg-slate-100/70 p-4.5 rounded-3xl border border-slate-200/80 space-y-3.5">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
            <h3 className="font-bold text-xs text-slate-700 uppercase tracking-wider">
              In Progress
            </h3>
          </div>
          <span className="text-xs font-bold bg-white text-slate-600 px-2 py-0.5 rounded-full border border-slate-200">
            {inProgressLessons.length}
          </span>
        </div>

        <div className="space-y-3">
          {inProgressLessons.map((lesson) => {
            const progress = (lesson.tasksCompleted / lesson.tasksTotal) * 100;
            return (
              <div
                key={lesson.id}
                onClick={() => handleOpenLesson(lesson)}
                className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3 hover:shadow-md transition-all cursor-pointer hover:border-blue-400 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                    {lesson.title}
                  </span>
                  <span className="text-[10px] bg-amber-50 text-amber-700 font-bold px-2 py-0.5 rounded-full border border-amber-200">
                    {lesson.tasksCompleted}/{lesson.tasksTotal}
                  </span>
                </div>
                <p className="text-xs text-slate-600 font-semibold">{lesson.subtitle}</p>
                <div className="text-[11px] text-slate-400 flex justify-between font-medium">
                  <span>
                    0{lesson.readingPoints} Tech Docs • 0{lesson.mathPoints} Code Labs
                  </span>
                  <span>{lesson.durationMins} Mins</span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-500 h-1.5 rounded-full"
                    style={{ width: `${progress}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Column 3: Completed */}
      <div className="bg-slate-100/70 p-4.5 rounded-3xl border border-slate-200/80 space-y-3.5">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center space-x-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <h3 className="font-bold text-xs text-slate-700 uppercase tracking-wider">
              Completed
            </h3>
          </div>
          <span className="text-xs font-bold bg-white text-slate-600 px-2 py-0.5 rounded-full border border-slate-200">
            {completedLessons.length}
          </span>
        </div>

        <div className="space-y-3">
          {completedLessons.map((lesson) => {
            return (
              <div
                key={lesson.id}
                onClick={() => handleOpenLesson(lesson)}
                className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3 hover:shadow-md transition-all cursor-pointer hover:border-blue-400 group"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                    {lesson.title}
                  </span>
                  <span className="text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-full border border-emerald-200">
                    {lesson.tasksCompleted}/{lesson.tasksTotal}
                  </span>
                </div>
                <p className="text-xs text-slate-600 font-semibold">{lesson.subtitle}</p>
                <div className="text-[11px] text-slate-400 flex justify-between font-medium">
                  <span>
                    0{lesson.readingPoints} Tech Docs • 0{lesson.mathPoints} Code Labs
                  </span>
                  <span>{lesson.durationMins} Mins</span>
                </div>
                <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-1.5 rounded-full w-full" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
