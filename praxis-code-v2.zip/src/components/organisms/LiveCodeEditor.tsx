import React, { useState } from 'react';
import { Play, RotateCcw, Sparkles, CheckCircle2, Lightbulb, Code2 } from 'lucide-react';
import { TestResultItem } from '../molecules/TestResultItem';
import { useApp } from '../../context/AppContext';

export const LiveCodeEditor: React.FC = () => {
  const { showToast } = useApp();
  const [activeTab, setActiveTab] = useState<'python' | 'js'>('python');

  const defaultPython = `# Desafio: Calcular fatia angular e fatias ativas
def calcular_fatias(numerador, denominador):
    # Verifica fração válida
    if denominador <= 0:
        return "Erro: denominador inválido"
    
    # Jane precisa de 3 partes de 4:
    fatia_fracao = numerador / denominador
    angulo_graus = (360 / denominador) * numerador
    return {"fracao": fatia_fracao, "angulo": angulo_graus}`;

  const defaultJs = `// Desafio: Renderizar fatias em Canvas
function calcularFatias(numerador, denominador) {
    if (denominador <= 0) return "Erro: denominador inválido";
    const fracao = numerador / denominador;
    const angulo = (2 * Math.PI / denominador) * numerador;
    return { fracao, radianos: angulo };
}`;

  const [code, setCode] = useState<string>(defaultPython);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [test3Status, setTest3Status] = useState<'pending' | 'running' | 'passed'>('pending');
  const [aiAnalysisOpen, setAiAnalysisOpen] = useState<boolean>(true);
  const [aiScore, setAiScore] = useState<string>('9.5 / 10 ⭐');
  const [aiFeedback, setAiFeedback] = useState<string>(
    'Excelente raciocínio, Jane! Você conectou perfeitamente o numerador e o denominador à proporção angular de um círculo completo (360°).'
  );

  const handleTabChange = (lang: 'python' | 'js') => {
    setActiveTab(lang);
    setCode(lang === 'python' ? defaultPython : defaultJs);
  };

  const handleRunCode = () => {
    setIsRunning(true);
    setTest3Status('running');

    setTimeout(() => {
      setIsRunning(false);
      setTest3Status('passed');
      setAiScore('10.0 / 10 🏆');
      setAiFeedback(
        'Incrível, Jane! Todos os 3 testes passaram com louvor! Você tratou a divisão por zero com elegância e o cálculo angular gerou o gráfico geométrico perfeito.'
      );
      showToast('Código executado com sucesso! Todos os testes passaram!');
    }, 900);
  };

  const handleReset = () => {
    setCode(activeTab === 'python' ? defaultPython : defaultJs);
    setTest3Status('pending');
    setAiScore('9.5 / 10 ⭐');
    setAiFeedback(
      'Excelente raciocínio, Jane! Você conectou perfeitamente o numerador e o denominador à proporção angular de um círculo completo (360°).'
    );
    showToast('Código resetado para o padrão original');
  };

  const handleAiEvaluation = () => {
    setAiAnalysisOpen(true);
    showToast('Análise de código atualizada com Assistente Pedagógico IA!');
  };

  const testsPassedCount = test3Status === 'passed' ? 3 : 2;
  const progressPercent = (testsPassedCount / 3) * 100;

  return (
    <div className="space-y-4">
      {/* Challenge Title */}
      <div className="space-y-1">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-blue-600" />
            Desafio Live Coding
          </span>
          <span className="text-[10px] font-semibold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full border border-emerald-200">
            Grade 2 • Nível 1
          </span>
        </div>
        <h3 className="text-base font-bold text-slate-900">Renderizador de Fatias de Fração</h3>
        <p className="text-xs text-slate-600 leading-relaxed">
          Complete a função para calcular o percentual e desenhar fatias correspondentes a{' '}
          <code className="bg-slate-100 text-blue-600 px-1 py-0.5 rounded font-mono text-[11px]">
            numerador / denominador
          </code>
          .
        </p>
      </div>

      {/* Code Editor Window */}
      <div className="rounded-xl overflow-hidden border border-slate-800 bg-[#0d1117] text-slate-200 shadow-md">
        {/* Editor Chrome Header */}
        <div className="bg-[#161b22] px-3 py-2 flex items-center justify-between border-b border-slate-800 text-xs">
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={() => handleTabChange('python')}
              className={`px-2.5 py-1 rounded font-mono text-[11px] font-medium flex items-center space-x-1.5 transition cursor-pointer ${
                activeTab === 'python'
                  ? 'bg-[#0d1117] text-white border border-slate-700/60'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-yellow-400" />
              <span>fraction_canvas.py</span>
            </button>
            <button
              type="button"
              onClick={() => handleTabChange('js')}
              className={`px-2.5 py-1 rounded font-mono text-[11px] font-medium flex items-center space-x-1.5 transition cursor-pointer ${
                activeTab === 'js'
                  ? 'bg-[#0d1117] text-white border border-slate-700/60'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-blue-400" />
              <span>solution.js</span>
            </button>
          </div>
          <div className="flex items-center space-x-1.5 text-slate-400 text-[11px]">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="font-mono text-[10px]">
              {activeTab === 'python' ? 'Python 3.11' : 'ESNext Engine'}
            </span>
          </div>
        </div>

        {/* Editor Lines and Input */}
        <div className="flex text-xs font-mono p-3 bg-[#0d1117] leading-relaxed overflow-x-auto min-h-[190px]">
          {/* Line Numbers */}
          <div className="select-none text-slate-600 text-right pr-3 font-mono space-y-0.5 text-[11px]">
            {code.split('\n').map((_, index) => (
              <div key={index}>{index + 1}</div>
            ))}
          </div>
          {/* Text Area */}
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            rows={code.split('\n').length || 10}
            spellCheck={false}
            className="w-full bg-transparent text-slate-200 focus:outline-none resize-none font-mono text-[11px] leading-relaxed p-0 border-none focus:ring-0"
          />
        </div>

        {/* Action Toolbar */}
        <div className="bg-[#161b22] px-3 py-2.5 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <button
              type="button"
              disabled={isRunning}
              onClick={handleRunCode}
              className="flex items-center space-x-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-xs font-semibold shadow-xs transition active:scale-95 cursor-pointer disabled:opacity-50"
            >
              {isRunning ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Executando...</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Executar Código</span>
                </>
              )}
            </button>
            <button
              type="button"
              onClick={handleReset}
              className="flex items-center space-x-1 text-slate-400 hover:text-white px-2 py-1.5 text-xs transition cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Resetar</span>
            </button>
          </div>

          <button
            type="button"
            onClick={handleAiEvaluation}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-bold text-white bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 shadow-md shadow-indigo-500/20 transition-all transform hover:-translate-y-0.5 active:scale-95 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>✨ Avaliação com IA</span>
          </button>
        </div>
      </div>

      {/* Automated Test Suite Progress */}
      <div className="border border-slate-200/90 rounded-2xl p-3.5 bg-slate-50/70 space-y-2.5">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            Test Suite Automática
          </span>
          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded-md tabular-nums">
            {testsPassedCount} de 3 Testes Concluídos {testsPassedCount === 3 ? '🎉' : ''}
          </span>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
          <div
            className="bg-emerald-500 h-full rounded-full transition-all duration-500"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        <div className="space-y-1.5 pt-1">
          <TestResultItem
            testNumber={1}
            label="Cálculo da fração unitária (1/4 = 0.25)"
            status="passed"
          />
          <TestResultItem
            testNumber={2}
            label="Ângulo para 3/4 fatias = 270 graus"
            status="passed"
          />
          <TestResultItem
            testNumber={3}
            label="Validação de divisão por zero (denominador == 0)"
            status={test3Status}
          />
        </div>
      </div>

      {/* AI Pedagogical Feedback Drawer */}
      {aiAnalysisOpen && (
        <div className="border border-indigo-200/80 bg-gradient-to-br from-indigo-50/80 via-purple-50/50 to-blue-50/40 rounded-2xl p-4 space-y-3 shadow-xs">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 rounded-lg bg-indigo-600 text-white flex items-center justify-center text-xs shadow-xs">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <h4 className="text-xs font-bold text-indigo-950">Assistente Pedagógico IA</h4>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
              Nota: {aiScore}
            </span>
          </div>

          <p className="text-xs text-indigo-900/90 leading-relaxed font-medium">{aiFeedback}</p>

          <div className="bg-white/90 backdrop-blur-xs rounded-xl p-2.5 border border-indigo-100/70 space-y-1 text-xs">
            <div className="flex items-center space-x-1.5 text-indigo-700 font-bold text-[11px]">
              <Lightbulb className="w-3.5 h-3.5 text-indigo-600" />
              <span>Dica Pedagógica do Tutor IA:</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Experimente alterar o valor do numerador para 1 na linha 8 e execute o código para
              observar o ângulo reduzir exatamente para 90°!
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
