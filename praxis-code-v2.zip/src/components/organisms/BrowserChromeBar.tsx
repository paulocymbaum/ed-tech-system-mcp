import React from 'react';
import { ChevronLeft, ChevronRight, RotateCw, Lock, Share2, Plus } from 'lucide-react';
import { useApp } from '../../context/AppContext';

export const BrowserChromeBar: React.FC = () => {
  const { currentPath, role } = useApp();

  const getUrl = () => {
    if (currentPath === 'role-select') return 'praxiscode.com/portal/roles';
    return `praxiscode.com/${role}/${currentPath}`;
  };

  return (
    <header className="bg-white border-b border-slate-200/90 px-4 py-2.5 flex items-center justify-between select-none text-xs text-slate-500 shadow-2xs z-30 shrink-0">
      <div className="flex items-center space-x-2">
        <div className="flex space-x-1.5">
          <span className="w-3 h-3 rounded-full bg-rose-400 inline-block hover:opacity-80 transition cursor-pointer" />
          <span className="w-3 h-3 rounded-full bg-amber-400 inline-block hover:opacity-80 transition cursor-pointer" />
          <span className="w-3 h-3 rounded-full bg-emerald-400 inline-block hover:opacity-80 transition cursor-pointer" />
        </div>
        <div className="flex items-center space-x-2.5 ml-3 text-slate-400">
          <button
            type="button"
            aria-label="Previous page"
            className="hover:text-slate-600 transition-colors p-0.5 rounded cursor-pointer"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            aria-label="Next page"
            className="hover:text-slate-600 transition-colors p-0.5 rounded cursor-pointer"
          >
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            aria-label="Refresh page"
            className="hover:text-slate-600 transition-colors p-0.5 rounded cursor-pointer"
          >
            <RotateCw className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Center URL Bar */}
      <div className="flex items-center bg-slate-100 hover:bg-slate-100/90 rounded-lg px-4 py-1 max-w-md w-full mx-4 text-slate-600 justify-center space-x-2 border border-slate-200/60 shadow-inner">
        <Lock className="w-3 h-3 text-slate-400 shrink-0" />
        <span className="font-medium text-slate-700 tracking-tight text-[11px] truncate">
          {getUrl()}
        </span>
      </div>

      <div className="flex items-center space-x-2.5 text-slate-400">
        <button
          type="button"
          aria-label="Share"
          className="hover:text-slate-600 transition-colors p-1 rounded cursor-pointer"
        >
          <Share2 className="w-3.5 h-3.5" />
        </button>
        <button
          type="button"
          aria-label="Add tab"
          className="hover:text-slate-600 transition-colors p-1 rounded cursor-pointer"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>
    </header>
  );
};
