import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Sparkles, Check, Brain } from 'lucide-react';
import { Button } from '../atoms/Button';

export interface QuizGeneratorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const QuizGeneratorModal: React.FC<QuizGeneratorModalProps> = ({ isOpen, onClose }) => {
  const { showToast } = useApp();
  const [topic, setTopic] = useState('Frações e Equivalência Numérica');
  const [gradeLevel, setGradeLevel] = useState('2º Ano (EF1)');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedQuestions, setGeneratedQuestions] = useState<string[] | null>(null);

  if (!isOpen) return null;

  const handleGenerate = () => {
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      setGeneratedQuestions([
        '1. Se você dividir uma pizza em 8 fatias iguais e comer 3 fatias, que fração representa o restante da pizza? (Resposta esperada: 5/8)',
        '2. Qual das opções representa uma fração equivalente a 1/2? (A: 2/4, B: 1/3, C: 3/5)',
        '3. Um círculo está dividido em 4 partes iguais. Se 2 partes estão pintadas de amarelo, que porcentagem do círculo está preenchida? (Resposta: 50%)',
      ]);
      showToast('3 Questões geradas com alinhamento à BNCC!');
    }, 800);
  };

  const handleApplyToLesson = () => {
    showToast('Questões incorporadas com sucesso ao banco da turma!');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">Gerador de Quizzes com IA</h3>
              <p className="text-xs text-slate-400">Geração pedagógica alinhada às normas BNCC</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs font-semibold">
          <div>
            <label className="block text-slate-700 mb-1">Tema / Objeto de Conhecimento</label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-purple-500 outline-none text-slate-800 font-normal"
            />
          </div>

          <div>
            <label className="block text-slate-700 mb-1">Ano Escolar / Faixa Etária</label>
            <select
              value={gradeLevel}
              onChange={(e) => setGradeLevel(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-purple-500 outline-none text-slate-800 font-normal bg-white"
            >
              <option value="1º Ano (EF1)">1º Ano (EF1 - 6 a 7 anos)</option>
              <option value="2º Ano (EF1)">2º Ano (EF1 - 7 a 8 anos)</option>
              <option value="3º Ano (EF1)">3º Ano (EF1 - 8 a 9 anos)</option>
              <option value="4º Ano (EF1)">4º Ano (EF1 - 9 a 10 anos)</option>
            </select>
          </div>

          {!generatedQuestions ? (
            <Button
              variant="gradient"
              size="md"
              className="w-full"
              isLoading={isGenerating}
              onClick={handleGenerate}
            >
              <Brain className="w-4 h-4 mr-2" />
              <span>Gerar Questões com IA</span>
            </Button>
          ) : (
            <div className="space-y-3 pt-2">
              <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Check className="w-4 h-4 text-emerald-600" />
                Questões Geradas:
              </span>
              <div className="space-y-2 max-h-48 overflow-y-auto p-3 bg-purple-50/50 rounded-xl border border-purple-100">
                {generatedQuestions.map((q, idx) => (
                  <p key={idx} className="text-xs text-slate-700 font-normal leading-relaxed pb-1 border-b border-purple-100/60 last:border-none">
                    {q}
                  </p>
                ))}
              </div>

              <div className="flex items-center justify-end space-x-2 pt-2">
                <Button variant="secondary" size="sm" onClick={() => setGeneratedQuestions(null)}>
                  Regenerar
                </Button>
                <Button variant="primary" size="sm" onClick={handleApplyToLesson}>
                  Adicionar ao Banco da Turma
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
