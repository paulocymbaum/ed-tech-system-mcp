import React from 'react';
import { useApp } from '../../context/AppContext';
import { ILesson } from '../../types';
import { Badge } from '../atoms/Badge';
import { Printer, ChevronDown, CheckCircle, ExternalLink, Maximize2, Award, Cpu } from 'lucide-react';
import { ProgressBar } from '../atoms/ProgressBar';

export interface WeeklyActivityListProps {
  onSelectLesson?: (lesson: ILesson) => void;
}

export const WeeklyActivityList: React.FC<WeeklyActivityListProps> = ({ onSelectLesson }) => {
  const { lessons, setCurrentPath, setActiveLessonId, showToast, openWorkspaceModal } = useApp();

  const handleOpenLesson = (lesson: ILesson) => {
    setActiveLessonId(lesson.id);
    setCurrentPath('lesson-plans');
    if (onSelectLesson) onSelectLesson(lesson);
  };

  const handlePrint = (e: React.MouseEvent, lesson: ILesson) => {
    e.stopPropagation();
    showToast(`Preparando impressão de atividades: ${lesson.title}`);
  };

  // SVGs matching the illustrations from Image 1
  const renderIllustration = (lessonNumber: number) => {
    switch (lessonNumber) {
      case 1:
        // Books Stack
        return (
          <svg className="w-24 h-24 text-blue-500" fill="none" viewBox="0 0 120 100">
            <ellipse cx="60" cy="85" fill="#E2E8F0" rx="42" ry="7" />
            <rect fill="#3B82F6" height="14" rx="4" width="70" x="25" y="68" />
            <rect fill="#93C5FD" height="3" rx="1.5" width="60" x="30" y="72" />
            <rect fill="#1D4ED8" height="10" rx="2" width="8" x="23" y="70" />
            <rect fill="#F97316" height="14" rx="4" width="62" x="32" y="52" />
            <rect fill="#FED7AA" height="3" rx="1.5" width="52" x="36" y="56" />
            <rect fill="#EA580C" height="10" rx="2" width="7" x="30" y="54" />
            <rect fill="#10B981" height="14" rx="4" width="52" x="38" y="36" />
            <rect fill="#A7F3D0" height="3" rx="1.5" width="42" x="42" y="40" />
            <circle cx="88" cy="28" fill="#FBBF24" r="3" />
            <circle cx="28" cy="45" fill="#60A5FA" r="2.5" />
            <path d="M92 48L94 52L98 54L94 56L92 60L90 56L86 54L90 52L92 48Z" fill="#F59E0B" />
          </svg>
        );
      case 2:
        // Calculator & Math Graph
        return (
          <svg className="w-24 h-24 text-indigo-500" fill="none" viewBox="0 0 120 100">
            <ellipse cx="60" cy="85" fill="#E2E8F0" rx="42" ry="7" />
            <rect fill="#3B82F6" height="58" rx="8" width="40" x="40" y="24" />
            <rect fill="#DBEAFE" height="12" rx="3" width="28" x="46" y="32" />
            <text fill="#1D4ED8" fontSize="7" fontWeight="bold" textAnchor="end" x="68" y="41">
              123456
            </text>
            <circle cx="50" cy="52" fill="#93C5FD" r="3" />
            <circle cx="60" cy="52" fill="#93C5FD" r="3" />
            <circle cx="70" cy="52" fill="#F97316" r="3" />
            <circle cx="50" cy="62" fill="#93C5FD" r="3" />
            <circle cx="60" cy="62" fill="#93C5FD" r="3" />
            <circle cx="70" cy="62" fill="#F97316" r="3" />
            <circle cx="50" cy="72" fill="#93C5FD" r="3" />
            <circle cx="60" cy="72" fill="#10B981" r="3" />
            <circle cx="70" cy="72" fill="#F97316" r="3" />
            <circle cx="28" cy="50" fill="#F59E0B" r="4.5" />
            <path d="M28 55L28 72M28 60L22 66M28 62L34 68" stroke="#1E293B" strokeLinecap="round" strokeWidth="2.5" />
            <circle cx="92" cy="48" fill="#3B82F6" r="4.5" />
            <path d="M92 53L92 70M92 58L86 64M92 60L98 64" stroke="#1E293B" strokeLinecap="round" strokeWidth="2.5" />
            <line stroke="#EF4444" strokeLinecap="round" strokeWidth="2" x1="97" x2="97" y1="40" y2="72" />
          </svg>
        );
      case 3:
        // Open Book & Bookmark
        return (
          <svg className="w-24 h-24 text-emerald-500" fill="none" viewBox="0 0 120 100">
            <ellipse cx="60" cy="85" fill="#E2E8F0" rx="42" ry="7" />
            <rect fill="#6366F1" height="14" rx="4" width="68" x="26" y="68" />
            <rect fill="#C7D2FE" height="3" rx="1.5" width="56" x="32" y="72" />
            <path d="M35 55C44 51 54 52 60 55C66 52 76 51 85 55V40C76 36 66 37 60 40C54 37 44 36 35 40V55Z" fill="#F8FAFC" stroke="#334155" strokeWidth="2" />
            <path d="M60 40V55" stroke="#334155" strokeWidth="2" />
            <path d="M48 37V49L52 46L56 49V37" fill="#EF4444" />
            <circle cx="85" cy="28" fill="#F59E0B" r="3" />
          </svg>
        );
      case 4:
        // Multiplier & STEM
        return (
          <svg className="w-24 h-24 text-rose-500" fill="none" viewBox="0 0 120 100">
            <ellipse cx="60" cy="85" fill="#E2E8F0" rx="42" ry="7" />
            <rect fill="#3B82F6" height="54" rx="6" width="36" x="42" y="26" />
            <rect fill="#EFF6FF" height="10" rx="2" width="26" x="47" y="32" />
            <circle cx="51" cy="50" fill="#BFDBFE" r="2.5" />
            <circle cx="60" cy="50" fill="#BFDBFE" r="2.5" />
            <circle cx="69" cy="50" fill="#F97316" r="2.5" />
            <circle cx="51" cy="60" fill="#BFDBFE" r="2.5" />
            <circle cx="60" cy="60" fill="#BFDBFE" r="2.5" />
            <circle cx="69" cy="60" fill="#10B981" r="2.5" />
            <circle cx="30" cy="52" fill="#F59E0B" r="4" />
            <path d="M30 56V72M30 62L24 67M30 62L36 67" stroke="#1E293B" strokeLinecap="round" strokeWidth="2" />
            <circle cx="90" cy="52" fill="#6366F1" r="4" />
            <path d="M90 56V72M90 62L84 67M90 62L96 67" stroke="#1E293B" strokeLinecap="round" strokeWidth="2" />
          </svg>
        );
      default:
        // Flask & Craft (Solar System / Science)
        return (
          <svg className="w-24 h-24 text-amber-500" fill="none" viewBox="0 0 120 100">
            <ellipse cx="60" cy="85" fill="#E2E8F0" rx="42" ry="7" />
            <path d="M55 35V45L42 68C40 72 43 76 48 76H72C77 76 80 72 78 68L65 45V35H55Z" fill="#E0F2FE" stroke="#0284C7" strokeWidth="2" />
            <path d="M47 68L52 58H68L73 68C74 70 73 72 70 72H50C47 72 46 70 47 68Z" fill="#38BDF8" />
            <circle cx="60" cy="65" fill="white" r="2" />
            <circle cx="56" cy="62" fill="white" r="1.5" />
            <circle cx="63" cy="55" fill="#38BDF8" r="1.5" />
            <circle cx="60" cy="30" fill="#F59E0B" r="2" />
          </svg>
        );
    }
  };

  return (
    <div className="space-y-4">
      {lessons.map((lesson) => {
        const progressPercent = (lesson.tasksCompleted / lesson.tasksTotal) * 100;
        const isCompleted = lesson.status === 'Completed';
        const isInProgress = lesson.status === 'In-Progress';

        return (
          <article
            key={lesson.id}
            onClick={() => handleOpenLesson(lesson)}
            className="bg-white rounded-3xl border border-slate-200/80 p-5 sm:p-6 shadow-xs hover:shadow-md card-transition hover:-translate-y-0.5 flex flex-col md:flex-row items-center gap-6 cursor-pointer group"
          >
            {/* Illustration Slot */}
            <div className="w-36 h-28 bg-slate-50 border border-slate-100 rounded-2xl flex items-center justify-center shrink-0 p-2 relative overflow-hidden group-hover:bg-blue-50/30 transition-colors">
              {renderIllustration(lesson.number)}
            </div>

            {/* Main Info & Metrics */}
            <div className="flex-1 w-full space-y-4">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-600 transition-colors">
                      {lesson.title}
                    </h3>
                    <Badge
                      variant={
                        isCompleted
                          ? 'completed'
                          : isInProgress
                          ? 'in-progress'
                          : 'not-started'
                      }
                      dot
                      size="sm"
                    >
                      {lesson.status}
                    </Badge>
                  </div>
                  <p className="text-xs text-slate-400 font-medium mt-0.5">
                    {lesson.subtitle}
                  </p>
                </div>

                <div className="flex items-center space-x-1.5 flex-wrap gap-1">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      openWorkspaceModal('quiz', lesson.id);
                    }}
                    title="Abrir Quiz de Lógica em Modal Centralizado (90%)"
                    className="inline-flex items-center space-x-1 px-2.5 py-1.5 rounded-xl border border-blue-200 text-[11px] font-bold text-blue-700 bg-blue-50/80 hover:bg-blue-100 transition-colors cursor-pointer shadow-2xs"
                  >
                    <Award className="w-3.5 h-3.5 text-blue-600" />
                    <span>Quiz (90%)</span>
                  </button>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      openWorkspaceModal('project', lesson.id);
                    }}
                    title="Abrir Projeto Maker em Modal Centralizado (90%)"
                    className="inline-flex items-center space-x-1 px-2.5 py-1.5 rounded-xl border border-purple-200 text-[11px] font-bold text-purple-700 bg-purple-50/80 hover:bg-purple-100 transition-colors cursor-pointer shadow-2xs"
                  >
                    <Cpu className="w-3.5 h-3.5 text-purple-600" />
                    <span>Projeto (90%)</span>
                  </button>

                  <button
                    type="button"
                    onClick={(e) => handlePrint(e, lesson)}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors cursor-pointer"
                  >
                    <Printer className="w-3.5 h-3.5 text-slate-400" />
                    <span className="hidden sm:inline">Print All Activity</span>
                  </button>
                  <button
                    type="button"
                    className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors cursor-pointer group-hover:border-blue-400 group-hover:text-blue-600"
                  >
                    <span>View</span>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-600" />
                  </button>
                </div>
              </div>

              {/* Data Grid: Coding Labs, Quizzes, Score */}
              <div className="grid grid-cols-3 gap-2 py-1 text-left">
                <div>
                  <span className="text-base font-bold text-slate-900 tabular-nums">
                    {lesson.projectsCompleted}/{lesson.projectsTotal} Done
                  </span>
                  <p className="text-[11px] text-slate-400 font-medium">Coding Labs</p>
                </div>

                <div>
                  <span className="text-base font-bold text-slate-900 tabular-nums">
                    {lesson.quizzesCompleted}/{lesson.quizzesTotal} Taken
                  </span>
                  <p className="text-[11px] text-slate-400 font-medium">Logic &amp; Syntax Quizzes</p>
                </div>

                <div>
                  {isCompleted ? (
                    <div>
                      <div className="inline-flex items-center space-x-1 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-lg">
                        <span className="text-xs">
                          {lesson.number === 4 ? '🏆' : '⭐'}
                        </span>
                        <span className="text-base font-bold text-emerald-700">
                          {lesson.finalScore}
                        </span>
                      </div>
                      <p className="text-[11px] text-emerald-600 font-medium">Final Score</p>
                    </div>
                  ) : isInProgress ? (
                    <div>
                      <div className="inline-flex items-center space-x-1 bg-amber-50 border border-amber-200 px-2.5 py-0.5 rounded-lg">
                        <span className="text-base font-bold text-amber-700">Pending</span>
                      </div>
                      <p className="text-[11px] text-amber-600 font-medium">Score Status</p>
                    </div>
                  ) : (
                    <div>
                      <div className="inline-flex items-center space-x-1 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-lg">
                        <span className="text-base font-bold text-slate-500">—</span>
                      </div>
                      <p className="text-[11px] text-slate-400 font-medium">Final Score</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Task Completion Bar */}
              <div className="flex items-center space-x-3 pt-1">
                <div className="flex-1 bg-slate-100 rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-2 rounded-full transition-all duration-500 ${
                      isCompleted ? 'bg-emerald-500' : isInProgress ? 'bg-emerald-500' : 'bg-slate-300'
                    }`}
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
                <span
                  className={`text-xs font-bold whitespace-nowrap tabular-nums ${
                    isCompleted
                      ? 'text-emerald-600'
                      : isInProgress
                      ? 'text-slate-700'
                      : 'text-slate-400'
                  }`}
                >
                  {lesson.tasksCompleted}/{lesson.tasksTotal} Tasks Completed ({Math.round(progressPercent)}%)
                </span>
              </div>
            </div>
          </article>
        );
      })}
    </div>
  );
};
