import React from 'react';
import { useApp } from '../../context/AppContext';

export const InteractiveFractionPizza: React.FC = () => {
  const { selectedSlices, toggleSlice } = useApp();

  const isSelected = (sliceIndex: number) => selectedSlices.includes(sliceIndex);
  const count = selectedSlices.length;

  return (
    <div className="bg-gradient-to-br from-slate-50 to-blue-50/40 rounded-2xl p-5 border border-slate-200/60 space-y-4">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <span className="text-xs font-bold text-slate-700 uppercase tracking-wide">
          Interactive Model: Click Slices to Inspect
        </span>
        <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-blue-600 text-white shadow-2xs">
          {count} / 4 Slices Selected
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
        {/* Pizza SVG Model */}
        <div className="flex flex-col items-center justify-center p-4 bg-white rounded-xl shadow-xs border border-slate-100 space-y-2 select-none">
          <svg className="w-40 h-40 cursor-pointer select-none" viewBox="0 0 100 100">
            {/* Slice 1 (Top-Left) */}
            <path
              onClick={() => toggleSlice(1)}
              className={`transition-colors duration-200 cursor-pointer ${
                isSelected(1)
                  ? 'fill-amber-400 hover:fill-amber-500'
                  : 'fill-slate-200 hover:fill-slate-300'
              }`}
              d="M50 50 L10 50 A40 40 0 0 1 50 10 Z"
              stroke="#ffffff"
              strokeWidth="2.5"
            />
            {/* Slice 2 (Top-Right) */}
            <path
              onClick={() => toggleSlice(2)}
              className={`transition-colors duration-200 cursor-pointer ${
                isSelected(2)
                  ? 'fill-amber-400 hover:fill-amber-500'
                  : 'fill-slate-200 hover:fill-slate-300'
              }`}
              d="M50 50 L50 10 A40 40 0 0 1 90 50 Z"
              stroke="#ffffff"
              strokeWidth="2.5"
            />
            {/* Slice 3 (Bottom-Right) */}
            <path
              onClick={() => toggleSlice(3)}
              className={`transition-colors duration-200 cursor-pointer ${
                isSelected(3)
                  ? 'fill-amber-400 hover:fill-amber-500'
                  : 'fill-slate-200 hover:fill-slate-300'
              }`}
              d="M50 50 L90 50 A40 40 0 0 1 50 90 Z"
              stroke="#ffffff"
              strokeWidth="2.5"
            />
            {/* Slice 4 (Bottom-Left) */}
            <path
              onClick={() => toggleSlice(4)}
              className={`transition-colors duration-200 cursor-pointer ${
                isSelected(4)
                  ? 'fill-amber-400 hover:fill-amber-500'
                  : 'fill-slate-200 hover:fill-slate-300'
              }`}
              d="M50 50 L50 90 A40 40 0 0 1 10 50 Z"
              stroke="#ffffff"
              strokeWidth="2.5"
            />
            {/* Center circle pin */}
            <circle cx="50" cy="50" fill="#ffffff" r="4.5" />
          </svg>
          <p className="text-xs font-medium text-slate-700">
            Pizza Circle: <strong className="text-blue-600 font-bold">{count} of 4</strong> quarters
          </p>
        </div>

        {/* Anatomy of a Fraction Callout */}
        <div className="flex flex-col justify-center space-y-3 bg-white p-4.5 rounded-xl shadow-xs border border-slate-100">
          <div className="flex items-center space-x-3.5">
            <div className="flex flex-col items-center bg-blue-50 px-3.5 py-2 rounded-xl text-blue-700 font-extrabold text-xl leading-none border border-blue-100">
              <span className="tabular-nums">{count}</span>
              <div className="w-5 h-0.5 bg-blue-600 my-1" />
              <span className="tabular-nums">4</span>
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900">Numerator ({count})</p>
              <p className="text-[11px] text-slate-500 leading-tight">
                Number of slices Jane has on her plate.
              </p>
              <div className="mt-1.5 pt-1.5 border-t border-slate-100">
                <p className="text-xs font-bold text-slate-900">Denominator (4)</p>
                <p className="text-[11px] text-slate-500 leading-tight">
                  Total slices the whole pizza was cut into.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
