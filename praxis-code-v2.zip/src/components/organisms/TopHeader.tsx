import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Plus, Bell, ChevronDown, Sparkles, BookOpen } from 'lucide-react';
import { Button } from '../atoms/Button';
import { Avatar } from '../atoms/Avatar';

export interface TopHeaderProps {
  onCreateLesson?: () => void;
}

export const TopHeader: React.FC<TopHeaderProps> = ({ onCreateLesson }) => {
  const { role, currentPath, activeStudent, showToast } = useApp();
  const [selectedTerm, setSelectedTerm] = useState('Semana 12 • 2º Bimestre');

  if (currentPath === 'lesson-plans') {
    // Top header is handled natively in the LessonDetailView with full breadcrumb & action bar
    return null;
  }

  return (
    <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 border-b border-slate-200/80 pb-5">
      <div>
        <div className="flex items-center space-x-2">
          <h1 className="text-2xl lg:text-3xl font-bold tracking-tight text-slate-900">
            {role === 'teacher' ? 'Teacher Dashboard' : 'Dashboard'}
          </h1>
          {role === 'teacher' && (
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 uppercase tracking-wider">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Teacher Mode
            </span>
          )}
        </div>
        <p className="text-xs text-slate-500 font-medium mt-1">
          {role === 'teacher'
            ? 'Acompanhamento pedagógico, avaliação de lições e progresso dos alunos'
            : 'Track daily lessons, completed tasks, and upcoming projects'}
        </p>
      </div>

      {role === 'teacher' ? (
        // Teacher Top Bar Controls
        <div className="flex items-center flex-wrap gap-3">
          {/* Term selector dropdown */}
          <div className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200/80 text-slate-700 text-xs font-semibold cursor-pointer transition border border-slate-200/60 shadow-2xs">
            <span>{selectedTerm}</span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-1" />
          </div>

          {/* Create Lesson CTA Button */}
          {onCreateLesson && (
            <Button
              variant="primary"
              size="sm"
              icon={<Plus className="w-4 h-4" />}
              onClick={onCreateLesson}
            >
              Criar Lição / Atividade
            </Button>
          )}

          {/* Notifications */}
          <button
            type="button"
            onClick={() => showToast('12 atividades aguardando revisão com IA')}
            className="relative p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition cursor-pointer border border-slate-200/60"
            title="Notificações"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white" />
          </button>

          {/* Teacher Profile */}
          <div className="flex items-center space-x-2.5 pl-2 border-l border-slate-200">
            <Avatar initials="SJ" bgGradient="from-indigo-600 to-blue-600" size="sm" isOnline />
            <div className="text-left hidden sm:block">
              <p className="text-xs font-bold text-slate-900 leading-tight">Prof. Sarah Jenkins</p>
              <span className="text-[10px] text-slate-400 font-medium">Educador Titular</span>
            </div>
          </div>
        </div>
      ) : (
        // Student Profile Header
        <div className="flex items-center space-x-3 bg-white px-3.5 py-2 rounded-2xl border border-slate-200/90 shadow-2xs">
          <Avatar initials={activeStudent.initials} size="md" isOnline bgGradient="from-blue-600 to-indigo-600" />
          <div className="text-left pr-2">
            <div className="flex items-center space-x-2">
              <span className="font-bold text-sm text-slate-900">{activeStudent.name}</span>
              <span className="bg-blue-50 text-blue-700 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-blue-200/60">
                {activeStudent.grade}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">Week of July 28 – August 1</p>
          </div>
        </div>
      )}
    </header>
  );
};
