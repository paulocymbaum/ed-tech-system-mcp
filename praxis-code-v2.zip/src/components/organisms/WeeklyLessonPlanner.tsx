import React from 'react';
import { useApp } from '../../context/AppContext';
import { ChevronLeft, ChevronRight, CheckCircle2, ExternalLink, Clock } from 'lucide-react';

export const WeeklyLessonPlanner: React.FC = () => {
  const { setCurrentPath, setActiveLessonId } = useApp();

  const handleOpenLesson = (lessonId: string) => {
    setActiveLessonId(lessonId);
    setCurrentPath('lesson-plans');
  };

  const scheduleItems = [
    {
      day: 'Segunda',
      isToday: false,
      lessonId: 'lesson-1',
      title: 'Lesson 1: Python Syntax & Storytelling',
      subject: 'Fundamentos de Python & Variáveis',
      statusBadge: 'Concluído por 4/4 alunos',
      statusColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      done: true,
    },
    {
      day: 'Hoje',
      isToday: true,
      lessonId: 'lesson-2',
      title: 'Lesson 2: Fractions & Python Turtle Geometry',
      subject: 'Computação Gráfica & Live Coding',
      statusBadge: '3/4 concluídos • 1 em andamento',
      statusColor: 'bg-blue-600 text-white font-bold',
      done: false,
    },
    {
      day: 'Quarta',
      isToday: false,
      lessonId: 'lesson-3',
      title: 'Lesson 3: Algoritmos de Fatiamento, Loops & Scratch',
      subject: 'Pensamento Computacional & Lógica',
      statusBadge: 'Amanhã 09:30',
      statusColor: 'bg-slate-100 text-slate-700 border-slate-200',
      done: false,
    },
    {
      day: 'Quinta',
      isToday: false,
      lessonId: 'lesson-4',
      title: 'Lesson 4: Loops, Arrays & Speed Math Drills',
      subject: 'Estruturas de Repetição & Benchmarks',
      statusBadge: 'Planejada',
      statusColor: 'bg-slate-100 text-slate-500 border-slate-200',
      done: false,
    },
    {
      day: 'Sexta',
      isToday: false,
      lessonId: 'lesson-5',
      title: 'Lesson 5: Pygame Physics & Orbital Simulation',
      subject: 'Simulação Física & Game Dev 2D',
      statusBadge: 'Planejada',
      statusColor: 'bg-slate-100 text-slate-500 border-slate-200',
      done: false,
    },
  ];

  return (
    <section className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
      {/* Header with week navigators */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-1">
        <div>
          <h2 className="text-lg font-bold text-slate-900 tracking-tight">
            Planejador de Lições da Semana
          </h2>
          <p className="text-xs text-slate-500 font-medium">
            Cronograma curricular alinhado aos marcos BNCC
          </p>
        </div>

        <div className="flex items-center space-x-1.5 self-start sm:self-auto bg-slate-100 p-1 rounded-xl">
          <button
            type="button"
            className="p-1 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-white transition cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-xs font-bold text-slate-800 px-2">Esta Semana</span>
          <button
            type="button"
            className="p-1 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-white transition cursor-pointer"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Rows */}
      <div className="space-y-2">
        {scheduleItems.map((item, idx) => (
          <div
            key={idx}
            onClick={() => handleOpenLesson(item.lessonId)}
            className={`p-3.5 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-all duration-150 cursor-pointer ${
              item.isToday
                ? 'bg-blue-50/80 border-2 border-blue-400 shadow-xs hover:bg-blue-100/60'
                : 'bg-slate-50/70 border border-slate-200/80 hover:bg-slate-100/70'
            }`}
          >
            <div className="flex items-center space-x-4">
              <div
                className={`w-20 font-bold text-xs uppercase tracking-wider ${
                  item.isToday ? 'text-blue-700 flex items-center gap-1.5' : 'text-slate-500'
                }`}
              >
                {item.isToday && (
                  <span className="w-2 h-2 rounded-full bg-blue-600 animate-ping" />
                )}
                <span>{item.day}</span>
              </div>

              <div>
                <span className="font-bold text-xs text-slate-900 block">{item.title}</span>
                <span className="text-[11px] text-slate-500 font-medium">{item.subject}</span>
              </div>
            </div>

            <div className="flex items-center space-x-3 pl-24 sm:pl-0 self-start sm:self-auto">
              <span
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold border ${item.statusColor}`}
              >
                {item.done ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                ) : item.isToday ? (
                  <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                ) : (
                  <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                )}
                <span>{item.statusBadge}</span>
              </span>

              <button
                type="button"
                className="p-1.5 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-lg transition"
                title="Abrir lição no ambiente de estudo"
              >
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
