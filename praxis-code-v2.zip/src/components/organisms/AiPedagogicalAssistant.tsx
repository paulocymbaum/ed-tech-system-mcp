import React from 'react';
import { useApp } from '../../context/AppContext';
import {
  Brain,
  AlertCircle,
  PartyPopper,
  Send,
  FileText,
  Calculator,
  Sparkles,
  Download,
  ExternalLink,
} from 'lucide-react';

export interface AiPedagogicalAssistantProps {
  onOpenQuizGenerator?: () => void;
}

export const AiPedagogicalAssistant: React.FC<AiPedagogicalAssistantProps> = ({
  onOpenQuizGenerator,
}) => {
  const { showToast } = useApp();

  const handleRecommendSupportLesson = () => {
    showToast('Lição de apoio interativa "Visualizando Frações no Código" recomendada para Theo Lima!');
  };

  return (
    <div className="space-y-5">
      {/* AI Assistant Card */}
      <section className="rounded-3xl p-5 sm:p-6 bg-gradient-to-br from-blue-50/90 via-indigo-50/70 to-purple-50/60 border border-blue-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-xs">
              <Brain className="w-4 h-4" />
            </div>
            <h3 className="font-bold text-sm text-slate-900">Assistente Pedagógico IA</h3>
          </div>
          <span className="px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 text-[10px] font-bold uppercase tracking-wider">
            Insights Ativos
          </span>
        </div>

        <div className="space-y-3">
          {/* Learning Alert: Theo Lima */}
          <div className="bg-white/95 backdrop-blur-xs rounded-2xl p-4 border border-rose-200/80 shadow-xs space-y-2">
            <div className="flex items-center gap-1.5 text-rose-600 font-bold text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>Alerta de Aprendizagem</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              <strong className="text-slate-900">Theo Lima</strong> apresentou hesitação no
              tratamento de exceções e divisão por zero em Python (2 tentativas incorretas no quiz de sintaxe). Recomendamos o
              envio do vídeo e lab complementar interativo{' '}
              <em className="text-slate-900 font-medium">"Visualizando Frações no Código (Canvas &amp; Python)"</em>.
            </p>
            <button
              type="button"
              onClick={handleRecommendSupportLesson}
              className="w-full py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer active:scale-98"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Recomendar Lição de Apoio</span>
            </button>
          </div>

          {/* Weekly Highlight: Jane Cooper */}
          <div className="bg-white/95 backdrop-blur-xs rounded-2xl p-4 border border-emerald-200/80 shadow-xs space-y-1">
            <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-xs">
              <PartyPopper className="w-4 h-4 shrink-0" />
              <span>Destaque da Semana</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              <strong className="text-slate-900">Jane Cooper</strong> completou o desafio de live
              coding com 10 minutos de antecedência e sem requisição de dicas de sintaxe.
            </p>
          </div>
        </div>
      </section>

      {/* Quick BNCC Resources */}
      <section className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs space-y-3">
        <h3 className="font-bold text-sm text-slate-900">Recursos Rápidos &amp; BNCC</h3>

        <div className="space-y-2">
          <a
            href="#bncc-curriculum"
            onClick={(e) => {
              e.preventDefault();
              showToast('Download do documento BNCC 2º Ano iniciado');
            }}
            className="flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-blue-50 border border-slate-200/70 hover:border-blue-200 transition group cursor-pointer"
          >
            <div className="flex items-center space-x-2.5">
              <FileText className="w-4 h-4 text-blue-600 shrink-0" />
              <span className="text-xs font-semibold text-slate-800 group-hover:text-blue-600 transition">
                Grade Curricular BNCC 2º Ano (PDF)
              </span>
            </div>
            <Download className="w-4 h-4 text-slate-400 group-hover:text-blue-600" />
          </a>

          <a
            href="#math-bank"
            onClick={(e) => {
              e.preventDefault();
              showToast('Abrindo repositório de 400 exercícios práticos');
            }}
            className="flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-blue-50 border border-slate-200/70 hover:border-blue-200 transition group cursor-pointer"
          >
            <div className="flex items-center space-x-2.5">
              <Calculator className="w-4 h-4 text-blue-600 shrink-0" />
              <span className="text-xs font-semibold text-slate-800 group-hover:text-blue-600 transition">
                Banco de Exercícios de Matemática
              </span>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-blue-600" />
          </a>

          <button
            type="button"
            onClick={onOpenQuizGenerator}
            className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-50 hover:bg-purple-50 border border-slate-200/70 hover:border-purple-200 transition group cursor-pointer text-left"
          >
            <div className="flex items-center space-x-2.5">
              <Sparkles className="w-4 h-4 text-purple-600 shrink-0" />
              <span className="text-xs font-semibold text-slate-800 group-hover:text-purple-600 transition">
                Gerador de Quizzes com IA
              </span>
            </div>
            <span className="text-[10px] font-bold text-purple-700 bg-purple-100 px-2 py-0.5 rounded-full">
              Gerar ✨
            </span>
          </button>
        </div>
      </section>
    </div>
  );
};
