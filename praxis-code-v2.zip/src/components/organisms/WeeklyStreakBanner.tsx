import React from 'react';
import { useApp } from '../../context/AppContext';

export const WeeklyStreakBanner: React.FC = () => {
  const { activeStudent } = useApp();

  return (
    <section className="bg-gradient-to-r from-blue-700 via-indigo-700 to-blue-800 rounded-3xl p-5 sm:p-6 text-white shadow-xl shadow-blue-900/10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-5 relative overflow-hidden">
      {/* Background ambient circular gradients */}
      <div className="absolute -right-10 -bottom-10 w-44 h-44 rounded-full bg-white/5 pointer-events-none" />
      <div className="absolute right-36 -top-8 w-28 h-28 rounded-full bg-blue-400/10 pointer-events-none" />

      {/* Left Message & Fire Icon */}
      <div className="flex items-center space-x-4 relative z-10">
        <div className="w-12 h-12 rounded-2xl bg-amber-400/20 border border-amber-300/30 flex items-center justify-center text-2xl shadow-inner shrink-0">
          🔥
        </div>
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-lg font-bold tracking-tight text-white">5 Day Streak!</span>
            <span className="bg-amber-400/25 text-amber-200 text-xs px-2.5 py-0.5 rounded-full font-semibold border border-amber-300/30">
              On Fire
            </span>
          </div>
          <p className="text-blue-100 text-xs mt-0.5">
            {activeStudent.name} has crushed all assigned lessons this week. Keep up the momentum!
          </p>
        </div>
      </div>

      {/* Weekly Streak Tracker Dots */}
      <div className="flex items-center space-x-2 self-start lg:self-auto bg-black/25 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/10 relative z-10">
        <span className="text-xs font-semibold text-blue-200 mr-2">Streak:</span>

        {/* Mon */}
        <div className="flex flex-col items-center">
          <div className="w-7 h-7 rounded-lg bg-emerald-500 text-white flex items-center justify-center text-xs font-bold shadow-xs">
            ✓
          </div>
          <span className="text-[10px] text-blue-200 mt-1 font-medium">Mon</span>
        </div>

        {/* Tue */}
        <div className="flex flex-col items-center">
          <div className="w-7 h-7 rounded-lg bg-emerald-500 text-white flex items-center justify-center text-xs font-bold shadow-xs">
            ✓
          </div>
          <span className="text-[10px] text-blue-200 mt-1 font-medium">Tue</span>
        </div>

        {/* Wed (Current Day) */}
        <div className="flex flex-col items-center">
          <div className="w-7 h-7 rounded-lg bg-blue-500 border border-blue-300 text-white flex items-center justify-center text-xs font-bold animate-pulse shadow-xs">
            3/4
          </div>
          <span className="text-[10px] text-white font-bold mt-1">Wed</span>
        </div>

        {/* Thu */}
        <div className="flex flex-col items-center opacity-60">
          <div className="w-7 h-7 rounded-lg bg-white/10 text-blue-200 flex items-center justify-center text-xs font-bold border border-white/10">
            0/4
          </div>
          <span className="text-[10px] text-blue-200 mt-1 font-medium">Thu</span>
        </div>

        {/* Fri */}
        <div className="flex flex-col items-center opacity-60">
          <div className="w-7 h-7 rounded-lg bg-white/10 text-blue-200 flex items-center justify-center text-xs font-bold border border-white/10">
            0/4
          </div>
          <span className="text-[10px] text-blue-200 mt-1 font-medium">Fri</span>
        </div>
      </div>
    </section>
  );
};
