import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { BrowserChromeBar } from '../organisms/BrowserChromeBar';
import { Sidebar } from '../organisms/Sidebar';
import { TopHeader } from '../organisms/TopHeader';
import { VideoPlayerModal } from '../organisms/VideoPlayerModal';
import { CreateLessonModal } from '../organisms/CreateLessonModal';
import { QuizGeneratorModal } from '../organisms/QuizGeneratorModal';
import { WorkspaceModal } from '../organisms/WorkspaceModal';

export interface AppLayoutProps {
  children: React.ReactNode;
}

export const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const { toastMessage, currentPath } = useApp();
  const [isCreateLessonOpen, setIsCreateLessonOpen] = useState(false);
  const [isQuizGeneratorOpen, setIsQuizGeneratorOpen] = useState(false);

  // If in role select mode, we can show full view or standard layout
  const isRoleSelect = currentPath === 'role-select';

  return (
    <div className="bg-[#f8fafc] text-slate-800 font-sans antialiased min-h-screen flex flex-col h-screen overflow-hidden selection:bg-blue-600 selection:text-white">
      {/* Top Simulated Browser Chrome Bar */}
      <BrowserChromeBar />

      <div className="flex flex-1 overflow-hidden">
        {/* Persistent Navigation Sidebar */}
        <Sidebar />

        {/* Main Scrollable Content Area */}
        <main className="flex-1 overflow-y-auto bg-[#f8fafc] px-5 sm:px-8 lg:px-10 py-6 sm:py-7 space-y-6">
          {!isRoleSelect && (
            <TopHeader
              onCreateLesson={() => setIsCreateLessonOpen(true)}
            />
          )}

          {children}
        </main>
      </div>

      {/* Global Modals */}
      <VideoPlayerModal />
      <WorkspaceModal />
      <CreateLessonModal
        isOpen={isCreateLessonOpen}
        onClose={() => setIsCreateLessonOpen(false)}
      />
      <QuizGeneratorModal
        isOpen={isQuizGeneratorOpen}
        onClose={() => setIsQuizGeneratorOpen(false)}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4.5 py-3 rounded-2xl shadow-xl flex items-center space-x-3 text-xs border border-slate-700 animate-in slide-in-from-bottom-5 duration-200">
          <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
          <span className="font-medium">{toastMessage}</span>
        </div>
      )}
    </div>
  );
};
