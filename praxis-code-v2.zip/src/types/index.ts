export type UserRole = 'student' | 'teacher';

export type NavigationPath = 
  | 'dashboard'
  | 'weekly-plan'
  | 'lesson-plans'
  | 'activities'
  | 'assessment'
  | 'resources'
  | 'my-students'
  | 'role-select';

export type LessonStatus = 'Completed' | 'In-Progress' | 'Not Started';

export interface ILesson {
  id: string;
  number: number;
  title: string;
  subtitle: string;
  day: string;
  subject: string;
  unit: string;
  level: string;
  status: LessonStatus;
  projectsCompleted: number;
  projectsTotal: number;
  quizzesCompleted: number;
  quizzesTotal: number;
  tasksCompleted: number;
  tasksTotal: number;
  finalScore?: string;
  scoreStatus?: 'Passed' | 'Pending' | 'None';
  durationMins: number;
  audioDuration: string;
  audioCurrent: string;
  description: string;
  readingPoints?: number;
  mathPoints?: number;
}

export interface IStudent {
  id: string;
  name: string;
  initials: string;
  grade: string;
  streakDays: number;
  progressPercent: number;
  xp: number;
  level: number;
  avatarColor: string;
  statusText: string;
  isOnline: boolean;
  hasAlert?: boolean;
  alertText?: string;
}

export interface IGradingSubmission {
  id: string;
  studentId: string;
  studentName: string;
  studentInitials: string;
  studentGrade: string;
  submittedAt: string;
  type: 'live-coding' | 'manual-project' | 'quiz';
  lessonId: string;
  lessonTitle: string;
  suggestedScore: number;
  aiFeedbackSummary: string;
  codeSnippet?: string;
  imageAttachment?: string;
  computerVisionNote?: string;
  status: 'pending' | 'approved' | 'reviewed';
}

export interface IVideoResource {
  id: string;
  title: string;
  channel: string;
  duration: string;
  verified: boolean;
  badge: string;
  embedFormula?: string;
}

export interface IExternalResource {
  id: string;
  title: string;
  category: string;
  description: string;
  url: string;
  badgeColor: 'indigo' | 'amber' | 'emerald';
}
