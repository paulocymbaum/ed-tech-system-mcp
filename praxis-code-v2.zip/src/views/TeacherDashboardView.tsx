import React from 'react';
import { useApp } from '../context/AppContext';
import { AiGradingQueue } from '../components/organisms/AiGradingQueue';
import { WeeklyLessonPlanner } from '../components/organisms/WeeklyLessonPlanner';
import { AiPedagogicalAssistant } from '../components/organisms/AiPedagogicalAssistant';
import { StudentProgressItem } from '../components/molecules/StudentProgressItem';
import {
  Users,
  CheckSquare,
  TrendingUp,
  Clock,
  ArrowRight,
  Verified,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { ProgressBar } from '../components/atoms/ProgressBar';

export interface TeacherDashboardViewProps {
  onOpenQuizGenerator?: () => void;
}

export const TeacherDashboardView: React.FC<TeacherDashboardViewProps> = ({
  onOpenQuizGenerator,
}) => {
  const { students, approveAllAiSubmissions, setCurrentPath, showToast } = useApp();

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Top Hero / Teacher Overview Metric Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Estudantes Ativos */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500">Estudantes Ativos</span>
              <div className="w-8 h-8 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
                <Users className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline gap-1.5 mb-1">
              <span className="text-3xl font-extrabold text-slate-900 tabular-nums">4</span>
              <span className="text-base font-bold text-slate-500">Alunos</span>
            </div>
            <p className="text-xs text-slate-400 truncate font-medium">
              Jane Cooper, Leo Silva, Maya, Theo
            </p>
          </div>
          <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-100 text-xs">
            <span className="text-slate-500 font-medium">100% de presença</span>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold text-[10px]">
              <TrendingUp className="w-3 h-3 text-emerald-600" />
              +12% engajamento
            </span>
          </div>
        </div>

        {/* Card 2: Atividades para Avaliar */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500">Atividades para Avaliar</span>
              <div className="w-8 h-8 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                <CheckSquare className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline gap-1.5 mb-1">
              <span className="text-3xl font-extrabold text-slate-900 tabular-nums">12</span>
              <span className="text-base font-bold text-slate-500">Pendentes</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-indigo-100/70 text-indigo-800 text-[10px] font-bold">
                <Sparkles className="w-3 h-3 text-indigo-600" />
                8 prontas com IA
              </span>
            </div>
          </div>
          <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-100 text-xs">
            <button
              type="button"
              onClick={approveAllAiSubmissions}
              className="text-blue-600 hover:text-blue-800 flex items-center gap-1 font-bold transition-colors cursor-pointer"
            >
              <span>Corrigir com 1-Clique</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
          </div>
        </div>

        {/* Card 3: Média Geral da Turma */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500">Média Geral da Turma</span>
              <div className="w-8 h-8 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline gap-1.5 mb-1">
              <span className="text-3xl font-extrabold text-slate-900 tabular-nums">8.9</span>
              <span className="text-base font-bold text-slate-500">/ 10</span>
            </div>
            <p className="text-xs text-slate-400 truncate font-medium">
              Python e Geometria Computacional em destaque
            </p>
          </div>
          <div className="flex items-center justify-between pt-3 mt-3 border-t border-slate-100 text-xs">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 font-bold text-[10px]">
              <Verified className="w-3 h-3 text-blue-600" />
              Acima da meta BNCC
            </span>
            <span className="text-[11px] text-emerald-700 font-bold">Meta: 8.0</span>
          </div>
        </div>

        {/* Card 4: Horas Dedicadas (Semana) */}
        <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs flex flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-slate-500">Horas Dedicadas (Semana)</span>
              <div className="w-8 h-8 rounded-xl bg-purple-50 flex items-center justify-center text-purple-600">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="flex items-baseline gap-1 mb-2">
              <span className="text-3xl font-extrabold text-slate-900 tabular-nums">28h 45m</span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500 font-medium mb-1">
              <span>Meta semanal: 30h</span>
              <span className="font-bold text-blue-600">95%</span>
            </div>
          </div>
          <div className="pt-2">
            <ProgressBar value={95} color="blue" size="xs" />
          </div>
        </div>
      </section>

      {/* Central Grid (7:5 desktop split) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Primary Pedagogical Flow (7 cols) */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          <AiGradingQueue />
          <WeeklyLessonPlanner />
        </div>

        {/* Right Column: Student Progress & AI Insights (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          {/* Widget 1: Acompanhamento Individual dos Alunos */}
          <section className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                  Acompanhamento dos Alunos
                </h2>
                <p className="text-xs text-slate-500 font-medium">Ritmo diário e retenção pedagógica</p>
              </div>
              <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 text-xs font-bold">
                {students.length} Ativos
              </span>
            </div>

            <div className="space-y-3">
              {students.map((student) => (
                <StudentProgressItem
                  key={student.id}
                  student={student}
                  onClick={() => {
                    setCurrentPath('my-students');
                    showToast(`Abrindo perfil individual de ${student.name}`);
                  }}
                />
              ))}
            </div>

            <button
              type="button"
              onClick={() => {
                setCurrentPath('my-students');
                showToast('Relatório pedagógico individual completo da turma');
              }}
              className="w-full mt-2 py-2.5 px-4 rounded-xl bg-slate-50 hover:bg-slate-100 text-blue-600 font-bold text-xs text-center transition flex items-center justify-center gap-1.5 border border-slate-200/60 cursor-pointer"
            >
              <span>Ver Relatório Individual Detalhado</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </section>

          {/* Widget 2: Assistente Pedagógico IA & BNCC */}
          <AiPedagogicalAssistant onOpenQuizGenerator={onOpenQuizGenerator} />
        </div>
      </div>
    </div>
  );
};
