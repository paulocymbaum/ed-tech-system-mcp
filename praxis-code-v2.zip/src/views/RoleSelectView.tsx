import React from 'react';
import { useApp } from '../context/AppContext';
import {
  GraduationCap,
  Sparkles,
  Flame,
  CheckCircle2,
  Check,
  Star,
  ArrowRight,
  Code2,
  Layers,
  Award,
  BookOpen,
  Calendar,
  Brain,
  BarChart3,
  ToggleLeft,
  Lightbulb,
  ExternalLink,
  Users,
  Clock,
} from 'lucide-react';

export const RoleSelectView: React.FC = () => {
  const { role, setRole, setCurrentPath } = useApp();

  const handleSelectRole = (selectedRole: 'teacher' | 'student') => {
    setRole(selectedRole);
    setCurrentPath('dashboard');
  };

  const isTeacher = role === 'teacher';
  const isStudent = role === 'student';

  return (
    <div className="max-w-6xl mx-auto py-4 space-y-8 animate-in fade-in duration-300">
      {/* 1. Header Section: Welcome & Context Banner */}
      <header className="flex flex-col items-center text-center max-w-3xl mx-auto pt-2">
        {/* Status Chip / Mandatory Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-50 text-blue-800 border border-blue-200/80 shadow-2xs">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-600 opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-600" />
          </span>
          <span className="text-[11px] font-bold uppercase tracking-wider">
            Acesso Obrigatório • Selecione seu papel para continuar
          </span>
        </div>

        <h1 className="mt-4 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Bem-vindo ao <span className="text-blue-600">Praxis Code</span>
        </h1>
        <p className="mt-2 text-sm sm:text-base text-slate-600 max-w-2xl leading-relaxed">
          Selecione seu perfil de acesso para personalizar sua rotina de estudos, painéis analíticos,
          biblioteca de recursos e ferramentas pedagógicas.
        </p>

        {/* Active Mode Quick Indicator */}
        <div className="mt-4 flex items-center gap-2 bg-white px-4 py-2 rounded-2xl border border-slate-200 shadow-xs text-slate-600 text-xs font-medium">
          <span>Perfil selecionado atualmente:</span>
          <span
            className={`font-bold px-2.5 py-0.5 rounded-full ${
              isTeacher
                ? 'bg-purple-100 text-purple-800'
                : 'bg-blue-100 text-blue-800'
            }`}
          >
            {isTeacher ? 'Teacher (Prof. Sarah Jenkins)' : 'Student (Jane Cooper)'}
          </span>
        </div>
      </header>

      {/* 2. Dual Interactive Role Cards (Side-by-Side Bento Split) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 w-full items-stretch">
        {/* CARD 1: TEACHER / EDUCATOR PROFILE */}
        <article
          onClick={() => handleSelectRole('teacher')}
          className={`group relative bg-white rounded-3xl p-6 sm:p-7 flex flex-col justify-between border transition-all duration-300 cursor-pointer ${
            isTeacher
              ? 'border-blue-500 shadow-2xl bg-blue-50/10 ring-2 ring-blue-500/20'
              : 'border-slate-200/90 shadow-md hover:shadow-xl hover:-translate-y-1'
          }`}
        >
          <div>
            {/* Header of Card */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-slate-100 text-slate-700 text-xs font-bold uppercase tracking-wider">
                <GraduationCap className="w-4 h-4 text-blue-600" />
                <span>Educator &amp; Parent</span>
              </div>

              {/* Selection Checkmark Dot */}
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors ${
                  isTeacher
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                <Check className="w-4 h-4 stroke-[3]" />
              </div>
            </div>

            {/* Hero Illustration & Content Block */}
            <div className="relative overflow-hidden rounded-2xl mb-6 h-44 bg-slate-50 border border-slate-200/80 flex items-center justify-between px-6 shadow-inner">
              <div className="flex flex-col gap-1 max-w-[55%] z-10">
                <span className="text-[11px] font-bold text-slate-400 uppercase">
                  Painel Pedagógico
                </span>
                <p className="text-lg font-bold text-slate-900 leading-snug">
                  Organização &amp; Metodologia
                </p>
                <div className="flex items-center gap-1.5 mt-2 text-blue-600 font-bold text-xs">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Relatórios de Aptidão BNCC</span>
                </div>
              </div>

              {/* Stylized graphic */}
              <div className="relative w-36 h-36 flex items-center justify-center">
                <div className="w-28 h-28 rounded-2xl bg-blue-100 rotate-6 absolute" />
                <div className="w-28 h-28 rounded-2xl bg-white -rotate-3 absolute flex flex-col p-3 shadow-md border border-slate-200/80">
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                    <span className="text-[10px] text-blue-600 font-bold">Semana 12</span>
                  </div>
                  <div className="h-2 w-full bg-blue-100 rounded-full mb-1.5">
                    <div className="h-2 w-3/4 bg-blue-600 rounded-full" />
                  </div>
                  <div className="h-1.5 w-1/2 bg-slate-200 rounded-full mb-2" />
                  <div className="mt-auto flex items-center gap-1 text-slate-500 font-medium text-[10px]">
                    <Users className="w-3 h-3" />
                    <span>4 Estudantes</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Title and Description */}
            <div className="mb-4">
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight mb-2">
                Acesso do Professor
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Gerencie planos de aula completos, monitore o progresso semanal de todos os alunos,
                gere correções com IA e atribua novas atividades curriculares de modo ágil.
              </p>
            </div>

            {/* Features Tags Grid */}
            <div className="grid grid-cols-2 gap-2 mb-6">
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/60 text-slate-800 text-xs font-semibold">
                <Users className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Gestão de Turmas</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/60 text-slate-800 text-xs font-semibold">
                <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Planejador de Lições</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/60 text-slate-800 text-xs font-semibold">
                <Brain className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Feedbacks com IA</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/60 text-slate-800 text-xs font-semibold">
                <BarChart3 className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Desempenho Geral</span>
              </div>
            </div>
          </div>

          {/* Card Footer & Action CTA */}
          <div className="pt-4 flex flex-col gap-3 bg-slate-50 -mx-6 sm:-mx-7 -mb-6 sm:-mb-7 p-6 sm:p-7 rounded-b-3xl border-t border-slate-100">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-slate-600 font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>3 turmas ativas • 12 atividades para avaliar</span>
              </div>
              <span className="text-slate-400 font-semibold">Modo Tutor</span>
            </div>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleSelectRole('teacher');
              }}
              className={`w-full py-3 px-4 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs ${
                isTeacher
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'bg-white hover:bg-blue-600 hover:text-white border border-slate-200 text-slate-800'
              }`}
            >
              <span>Entrar como Professor</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </article>

        {/* CARD 2: STUDENT PROFILE */}
        <article
          onClick={() => handleSelectRole('student')}
          className={`group relative bg-white rounded-3xl p-6 sm:p-7 flex flex-col justify-between border transition-all duration-300 cursor-pointer ${
            isStudent
              ? 'border-blue-500 shadow-2xl bg-blue-50/10 ring-2 ring-blue-500/20'
              : 'border-slate-200/90 shadow-md hover:shadow-xl hover:-translate-y-1'
          }`}
        >
          {/* Elevated highlight badge ribbon */}
          <div className="absolute -top-3 right-6 z-20">
            <div className="flex items-center gap-1 bg-blue-600 text-white px-3 py-1 rounded-full shadow-md text-[10px] font-extrabold tracking-wider uppercase">
              <Star className="w-3 h-3 fill-current" />
              <span>Perfil Recomendado</span>
            </div>
          </div>

          <div>
            {/* Header of Card */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold uppercase tracking-wider border border-blue-200/70">
                <Flame className="w-4 h-4 text-amber-500" />
                <span>Student Experience</span>
              </div>

              {/* Selection Checkmark Dot */}
              <div
                className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors ${
                  isStudent
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-400'
                }`}
              >
                <Check className="w-4 h-4 stroke-[3]" />
              </div>
            </div>

            {/* Hero Illustration Banner / Student Metrics */}
            <div className="relative overflow-hidden rounded-2xl mb-6 h-44 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 text-white flex items-center justify-between px-6 shadow-md">
              <div className="flex flex-col gap-1 max-w-[60%] z-10">
                <div className="inline-flex items-center gap-1.5 bg-white/20 backdrop-blur-md px-2.5 py-0.5 rounded-full w-max text-white text-[11px] font-bold">
                  <span>🔥 5 Dias de Ofensiva</span>
                </div>
                <p className="text-xl font-bold text-white leading-tight mt-1">Jane Cooper</p>
                <p className="text-xs text-blue-100 font-medium">Nível 7 • 1.450 XP conquistados</p>
              </div>

              {/* Mini Interactive Visual Widget */}
              <div className="relative z-10 flex flex-col items-center justify-center bg-white text-slate-800 p-3 rounded-2xl shadow-lg w-28">
                <div className="relative flex items-center justify-center w-14 h-14">
                  <svg className="w-14 h-14 -rotate-90" viewBox="0 0 36 36">
                    <path
                      className="text-slate-100"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="3.5"
                    />
                    <path
                      className="text-blue-600"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                      fill="none"
                      stroke="currentColor"
                      strokeDasharray="82, 100"
                      strokeLinecap="round"
                      strokeWidth="3.5"
                    />
                  </svg>
                  <span className="absolute text-xs font-bold text-slate-900">82%</span>
                </div>
                <span className="text-[10px] text-slate-500 mt-1 font-bold uppercase">
                  Meta Diária
                </span>
              </div>
            </div>

            {/* Title and Description */}
            <div className="mb-4">
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight mb-2">
                Acesso do Estudante
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Acesse suas lições do dia, complete desafios de live coding, mantenha sua ofensiva
                diária e ganhe medalhas interativas com acompanhamento em tempo real.
              </p>
            </div>

            {/* Features Tags Grid */}
            <div className="grid grid-cols-2 gap-2 mb-6">
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/60 text-slate-800 text-xs font-semibold">
                <BookOpen className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Lições Interativas</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/60 text-slate-800 text-xs font-semibold">
                <Code2 className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Live Coding &amp; Labs</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/60 text-slate-800 text-xs font-semibold">
                <Award className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Medalhas &amp; XP</span>
              </div>
              <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200/60 text-slate-800 text-xs font-semibold">
                <Layers className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Projetos Práticos</span>
              </div>
            </div>
          </div>

          {/* Card Footer & Action CTA */}
          <div className="pt-4 flex flex-col gap-3 bg-slate-50 -mx-6 sm:-mx-7 -mb-6 sm:-mb-7 p-6 sm:p-7 rounded-b-3xl border-t border-slate-100">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-slate-600 font-medium">
                <Clock className="w-4 h-4 text-blue-600" />
                <span>Próxima aula às 10:30 • Frações e Geometria</span>
              </div>
              <span className="text-blue-600 font-bold">Jane C.</span>
            </div>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleSelectRole('student');
              }}
              className={`w-full py-3 px-4 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs ${
                isStudent
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                  : 'bg-white hover:bg-blue-600 hover:text-white border border-slate-200 text-slate-800'
              }`}
            >
              <span>Entrar como Estudante (Jane Cooper)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </article>
      </div>

      {/* 3. Bottom Information & Switcher Support Panel */}
      <footer className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Quick Switcher Notice Card */}
        <div className="md:col-span-2 bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
            <ToggleLeft className="w-6 h-6" />
          </div>
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-slate-900">
              Alternância rápida entre perfis a qualquer momento
            </h3>
            <p className="text-xs text-slate-600 leading-relaxed">
              Você pode alternar instantaneamente entre o modo Professor e Estudante usando o
              seletor em cápsula no menu lateral ou nas configurações rápidas, sem precisar fazer
              logout ou perder seus rascunhos de aula.
            </p>
            <div className="mt-3 flex items-center gap-2">
              <span className="text-[11px] text-slate-400 font-medium">Atalho Rápido:</span>
              <button
                type="button"
                onClick={() => handleSelectRole('teacher')}
                className="px-3 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold transition cursor-pointer"
              >
                Modo Professor
              </button>
              <button
                type="button"
                onClick={() => handleSelectRole('student')}
                className="px-3 py-1 rounded-lg bg-blue-100 hover:bg-blue-200 text-blue-800 text-xs font-bold transition cursor-pointer"
              >
                Modo Estudante
              </button>
            </div>
          </div>
        </div>

        {/* Quick Tips Card */}
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-1.5 text-blue-600 font-bold text-xs">
              <Lightbulb className="w-4 h-4" />
              <span>Primeiros Passos</span>
            </div>
            <ul className="space-y-1.5 text-xs text-slate-600">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0" />
                <span>Configure a grade horária semanal no Weekly Plan.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0" />
                <span>Adicione membros da família em My Students.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0" />
                <span>Ative a sincronização em tempo real de notas.</span>
              </li>
            </ul>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100">
            <a
              href="#help"
              onClick={(e) => {
                e.preventDefault();
                setCurrentPath('resources');
              }}
              className="inline-flex items-center gap-1 text-xs font-bold text-blue-600 hover:underline"
            >
              <span>Ver Central de Ajuda &amp; Tutoriais</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
};
