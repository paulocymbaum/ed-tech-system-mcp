import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { VIDEO_RESOURCES, EXTERNAL_RESOURCES } from '../constants/mockData';
import { AudioNarratorPlayer } from '../components/molecules/AudioNarratorPlayer';
import { InteractiveFractionPizza } from '../components/organisms/InteractiveFractionPizza';
import { LiveCodeEditor } from '../components/organisms/LiveCodeEditor';
import { VideoCard } from '../components/molecules/VideoCard';
import { ChecklistItem } from '../components/molecules/ChecklistItem';
import { QuizOptionCard } from '../components/molecules/QuizOptionCard';
import {
  Volume2,
  Clock,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Upload,
  FileDown,
  HelpCircle,
  PhoneCall,
  Scissors,
  Pencil,
  FileSpreadsheet,
  Award,
  Video,
  ExternalLink,
  Code2,
  Cpu,
  Terminal,
  Maximize2,
} from 'lucide-react';
import { Avatar } from '../components/atoms/Avatar';
import { Button } from '../components/atoms/Button';

export const LessonDetailView: React.FC = () => {
  const {
    activeStudent,
    setActiveVideoModal,
    setCurrentPath,
    showToast,
    updateLessonProgress,
    selectedSlices,
    openWorkspaceModal,
  } = useApp();

  // Active right workspace tab
  const [workspaceTab, setWorkspaceTab] = useState<'coding' | 'project' | 'quiz'>('coding');

  // Audio narration toggle state
  const [isAudioGuideActive, setIsAudioGuideActive] = useState(false);

  // Hands-on project checklist state
  const [checklist, setChecklist] = useState({
    step1: true,
    step2: false,
    step3: false,
    step4: false,
  });

  // Quiz state
  const [selectedQ1, setSelectedQ1] = useState<'A' | 'B' | null>('A');
  const [selectedQ2, setSelectedQ2] = useState<string>('0.75');
  const [quizScoreBadge, setQuizScoreBadge] = useState<string | null>(null);

  // Project photo upload simulation
  const [uploadedPhoto, setUploadedPhoto] = useState<string | null>(null);

  const toggleChecklist = (step: 'step1' | 'step2' | 'step3' | 'step4') => {
    setChecklist((prev) => {
      const next = { ...prev, [step]: !prev[step] };
      const completedSteps = Object.values(next).filter(Boolean).length;
      updateLessonProgress('lesson-2', { tasksCompleted: completedSteps });
      return next;
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const previewUrl = URL.createObjectURL(file);
      setUploadedPhoto(previewUrl);
      showToast(`Foto do protótipo maker "${file.name}" carregada com sucesso!`);
      if (!checklist.step4) {
        toggleChecklist('step4');
      }
    }
  };

  const handleCheckQuiz = () => {
    setQuizScoreBadge('3/3 Acertos (100%) ⭐ - Excelente raciocínio algorítmico!');
    showToast('Parabéns! Todas as respostas sobre sintaxe e cálculo computacional estão corretas!');
  };

  const handleSaveProgress = () => {
    showToast('Progresso e código da Lesson 2 salvos com sucesso na nuvem!');
  };

  const toggleAudioGuide = () => {
    setIsAudioGuideActive(!isAudioGuideActive);
    showToast(
      isAudioGuideActive
        ? 'Áudio-guia pausado'
        : 'Reproduzindo áudio-guia: Lógica de Ângulos e Frações em Código'
    );
  };

  const count = selectedSlices.length;
  const currentDegrees = Math.round((360 / 4) * count);
  const currentFloat = (count / 4).toFixed(2);

  return (
    <div className="flex flex-col w-full space-y-6 max-w-7xl mx-auto">
      {/* Top Navigation & Lesson Header Bar */}
      <section className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white p-5 sm:p-6 rounded-3xl border border-slate-200/80 shadow-xs">
        <div className="flex flex-col space-y-1.5">
          {/* Breadcrumbs */}
          <nav className="flex items-center space-x-2 text-xs font-medium text-slate-400">
            <span
              onClick={() => setCurrentPath('dashboard')}
              className="hover:text-slate-600 cursor-pointer"
            >
              Praxis Code
            </span>
            <span>/</span>
            <span
              onClick={() => setCurrentPath('lesson-plans')}
              className="hover:text-slate-600 cursor-pointer"
            >
              Computer Science &amp; Math
            </span>
            <span>/</span>
            <span className="text-slate-500 font-medium">Python Graphics</span>
            <span>/</span>
            <span className="text-blue-600 font-bold">Lesson 2</span>
          </nav>

          {/* Title & Status Badges */}
          <div className="flex flex-wrap items-center gap-3 pt-0.5">
            <h1 className="text-xl md:text-2xl font-bold text-slate-900 tracking-tight">
              Lesson 2: Fractions &amp; Python Turtle Geometry
            </h1>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200">
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
              In-Progress
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium bg-slate-100 text-slate-600">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              22 mins active
            </span>
          </div>
        </div>

        {/* Student & Audio Action Controls */}
        <div className="flex items-center flex-wrap gap-3">
          {/* Audio Narration Pill */}
          <button
            type="button"
            onClick={toggleAudioGuide}
            className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer border ${
              isAudioGuideActive
                ? 'bg-blue-50 text-blue-700 border-blue-200'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-transparent'
            }`}
          >
            <Volume2 className="w-4 h-4 text-blue-600" />
            <span>{isAudioGuideActive ? 'Audio Playing...' : 'Audio Guide (Code)'}</span>
          </button>

          {/* Student Profile Badge */}
          <div className="flex items-center space-x-2.5 px-3 py-1.5 bg-slate-50 rounded-xl border border-slate-200/80">
            <Avatar initials={activeStudent.initials} size="sm" isOnline bgGradient="from-pink-400 to-rose-500" />
            <div className="text-left">
              <p className="text-xs font-bold text-slate-800 leading-tight">
                {activeStudent.name}
              </p>
              <span className="text-[10px] text-slate-500 font-medium bg-slate-200/80 px-1.5 py-0.5 rounded">
                {activeStudent.grade}
              </span>
            </div>
          </div>

          {/* Save Progress CTA */}
          <Button
            variant="primary"
            size="sm"
            onClick={handleSaveProgress}
            icon={<Check className="w-4 h-4" />}
          >
            Save Progress
          </Button>
        </div>
      </section>

      {/* Dual-Panel Simultaneous View Layout (Left: Theory/Explanation, Right: Work/Project/Quiz) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT PANEL: Theory & Concept Explanation + Multimedia (7 cols ~ 58%) */}
        <section className="lg:col-span-7 flex flex-col space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/80 shadow-xs space-y-6">
            {/* Metadata Header */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider rounded-md bg-blue-50 text-blue-700 border border-blue-100 flex items-center gap-1">
                  <Terminal className="w-3 h-3" /> Python • Unit 4
                </span>
                <span className="px-2.5 py-1 text-[11px] font-semibold rounded-md bg-emerald-50 text-emerald-700 border border-emerald-100">
                  Level: Beginner Coder
                </span>
              </div>
              <div className="flex items-center space-x-1 text-slate-400 text-xs font-medium">
                <Clock className="w-4 h-4 text-slate-400" />
                <span>Est. 45 Min Total</span>
              </div>
            </div>

            {/* Audio Player Strip */}
            <AudioNarratorPlayer
              title="Lesson Narration (Audio Lesson)"
              subtitle="Listen to Miss Sarah explain Algorithm Angles & Fraction Logic"
              duration="08:30"
              current="02:14"
            />

            {/* Explanation Block: What is a Fraction in Code? */}
            <div className="space-y-3">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2.5">
                <span className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 text-blue-600 text-xs font-extrabold">
                  1
                </span>
                What is a Fraction in Code? (Frações em Algoritmos &amp; Proporções)
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Na programação e computação gráfica, uma <strong>fração</strong> representa a razão entre
                partes e um todo. Quando desenhamos gráficos circulares (pie charts), fatias de pizza em
                jogos 2D ou barras de energia, o computador calcula uma proporção de ponto flutuante:
                <code className="mx-1 px-1.5 py-0.5 rounded bg-slate-100 text-blue-600 font-mono text-xs">
                  fraction = numerator / denominator
                </code>
                . Para renderizar visualmente no Canvas ou em Python Turtle, convertemos essa fração
                em graus:
                <code className="mx-1 px-1.5 py-0.5 rounded bg-slate-100 text-purple-600 font-mono text-xs">
                  angle = (360 / denominator) * numerator
                </code>
                .
              </p>
            </div>

            {/* Interactive Pizza & Model Visualizer */}
            <div className="space-y-2">
              <InteractiveFractionPizza />
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/60 flex items-center justify-between text-xs text-slate-700 font-mono">
                <span className="text-slate-500">Cálculo de Renderização em Tempo Real:</span>
                <span className="font-bold text-blue-600">
                  angle = (360 / 4) * {count} = {currentDegrees}° ({currentFloat}f)
                </span>
              </div>
            </div>

            {/* Pastel Tip Box: ZeroDivisionError Prevention */}
            <div className="flex items-start space-x-3.5 bg-emerald-50 rounded-2xl p-4.5 text-emerald-900 border border-emerald-200/60">
              <div className="w-8 h-8 rounded-xl bg-emerald-100 flex items-center justify-center shrink-0 text-emerald-700 font-bold">
                🛡️
              </div>
              <div className="space-y-0.5">
                <h4 className="text-xs font-bold text-emerald-950 uppercase tracking-wide">
                  Dica de Ouro de Programação Defensiva:
                </h4>
                <p className="text-xs text-emerald-800 leading-relaxed">
                  O <strong>Denominator</strong> fica Embaixo (Down). Cuidado com o bug clássico de{' '}
                  <code className="font-mono bg-emerald-100/80 px-1 rounded text-emerald-950 font-bold">
                    ZeroDivisionError: division by zero
                  </code>
                  ! Se um usuário inserir denominador zero, seu programa pode travar. Sempre valide{' '}
                  <code className="font-mono bg-emerald-100/80 px-1 rounded text-emerald-950 font-bold">
                    if denominator &lt;= 0:
                  </code>{' '}
                  antes de executar a divisão!
                </p>
              </div>
            </div>

            {/* Key Vocabulary Cards for Young Coders */}
            <div className="space-y-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Code2 className="w-4 h-4 text-blue-600" />
                <span>Vocabulário Técnico para Coders (Grade 2)</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 p-3.5 rounded-2xl text-center border border-slate-200/60">
                  <span className="block text-xs font-extrabold text-blue-600">Float</span>
                  <span className="text-[10px] text-slate-500 font-medium">1.0 (Ponto Flutuante)</span>
                  <div className="w-7 h-7 mx-auto mt-2 rounded-full bg-blue-500 shadow-2xs" />
                </div>

                <div className="bg-slate-50 p-3.5 rounded-2xl text-center border border-slate-200/60">
                  <span className="block text-xs font-extrabold text-blue-600">Half (0.5)</span>
                  <span className="text-[10px] text-slate-500 font-medium">180° Radianos</span>
                  <div className="w-7 h-7 mx-auto mt-2 rounded-full bg-blue-500 relative overflow-hidden shadow-2xs">
                    <div className="w-3.5 h-7 bg-slate-300" />
                  </div>
                </div>

                <div className="bg-slate-50 p-3.5 rounded-2xl text-center border border-slate-200/60">
                  <span className="block text-xs font-extrabold text-blue-600">Quarter (0.25)</span>
                  <span className="text-[10px] text-slate-500 font-medium">90° no Plano 2D</span>
                  <div className="w-7 h-7 mx-auto mt-2 rounded-full bg-slate-300 relative overflow-hidden shadow-2xs">
                    <div className="w-3.5 h-3.5 bg-blue-500 absolute top-0 left-0" />
                  </div>
                </div>

                <div className="bg-slate-50 p-3.5 rounded-2xl text-center border border-slate-200/60">
                  <span className="block text-xs font-extrabold text-blue-600">Array / List</span>
                  <span className="text-[10px] text-slate-500 font-medium">[1, 1, 1, 0]</span>
                  <div className="w-7 h-7 mx-auto mt-2 rounded-full bg-slate-300 flex shadow-2xs overflow-hidden">
                    <div className="w-2.5 h-7 bg-blue-500" />
                  </div>
                </div>
              </div>
            </div>

            {/* Accordion for Parent / Tutor Guidance */}
            <details className="group bg-slate-50 rounded-2xl overflow-hidden cursor-pointer border border-slate-200/60">
              <summary className="flex items-center justify-between p-4 font-semibold text-xs text-slate-700 select-none">
                <span className="flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-blue-600" />
                  Notas Pedagógicas para Educadores &amp; Pais (Clique para expandir)
                </span>
                <ChevronDown className="w-4 h-4 text-slate-400 group-open:rotate-180 transition-transform" />
              </summary>
              <div className="px-4 pb-4 text-xs text-slate-600 space-y-2 border-t border-slate-200/40 pt-3">
                <p>
                  Esta lição desenvolve o pensamento computacional através da conexão entre aritmética
                  fracionária e renderização visual. Ao programar a função{' '}
                  <code className="bg-slate-200 px-1 rounded font-mono text-[11px]">
                    calcular_fatias()
                  </code>
                  , a criança consolida noções de proporção, listas indexadas e estruturas de controle
                  condicional.
                </p>
                <p className="text-[11px] text-slate-500">
                  Alinhamento curricular: BNCC Computação no Ensino Fundamental (Pensamento
                  Computacional e Algoritmos) &amp; CSTA K-12 CS Standards (1B-AP-10).
                </p>
              </div>
            </details>
          </div>

          {/* SEÇÃO: Recursos Complementares & Mídias da Aula */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3.5">
              <div className="flex items-center space-x-2.5">
                <div className="w-8 h-8 rounded-xl bg-red-50 text-red-600 flex items-center justify-center font-bold">
                  <Video className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900">
                    Aulas em Vídeo de Programação &amp; Playgrounds
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Tutoriais em vídeo de Python e ambientes interativos de código
                  </p>
                </div>
              </div>
              <span className="text-[11px] font-semibold bg-slate-100 text-slate-600 px-2.5 py-1 rounded-full">
                4 recursos de tech
              </span>
            </div>

            {/* Subseção: Vídeos do YouTube */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-red-500" />
                  Vídeos de Coding Recomendados
                </span>
                <span className="text-[11px] text-slate-400">Clique para abrir o player</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {VIDEO_RESOURCES.map((video) => (
                  <VideoCard
                    key={video.id}
                    video={video}
                    onPlay={(v) => setActiveVideoModal(v)}
                  />
                ))}
              </div>
            </div>

            {/* Subseção: Links Externos Recomendados */}
            <div className="space-y-3 pt-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <ExternalLink className="w-3.5 h-3.5 text-blue-600" />
                Playgrounds Interativos de Código
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {EXTERNAL_RESOURCES.map((res) => (
                  <a
                    key={res.id}
                    href={res.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3.5 rounded-2xl border border-slate-200/80 bg-slate-50/50 hover:bg-blue-50/40 hover:border-blue-300 transition flex items-start justify-between group"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-xs font-bold text-slate-900 group-hover:text-blue-600 transition">
                          {res.title}
                        </span>
                        <span className="px-1.5 py-0.5 text-[9px] font-bold uppercase rounded bg-indigo-100 text-indigo-700">
                          {res.category}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 leading-snug">
                        {res.description}
                      </p>
                    </div>
                    <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-blue-600 shrink-0 ml-2 mt-0.5 transition" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* RIGHT PANEL: Simultaneous Workspace (Coding / Hardware Maker / Quiz) (5 cols ~ 42%) */}
        <aside className="lg:col-span-5 flex flex-col space-y-4 lg:sticky lg:top-4">
          <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden flex flex-col">
            {/* Workspace Tab Switcher Header */}
            <div className="flex items-center justify-between bg-slate-100/90 p-1.5 m-3 rounded-2xl border border-slate-200/60">
              <div className="flex items-center flex-1 gap-1">
                <button
                  type="button"
                  onClick={() => setWorkspaceTab('coding')}
                  className={`flex-1 flex items-center justify-center space-x-1.5 py-2 px-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    workspaceTab === 'coding'
                      ? 'bg-white text-blue-700 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Code2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>Live Coding</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                </button>

                <button
                  type="button"
                  onClick={() => setWorkspaceTab('project')}
                  className={`flex-1 flex items-center justify-center space-x-1.5 py-2 px-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    workspaceTab === 'project'
                      ? 'bg-white text-blue-700 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Cpu className="w-3.5 h-3.5 text-slate-500" />
                  <span>Hardware Maker</span>
                </button>

                <button
                  type="button"
                  onClick={() => setWorkspaceTab('quiz')}
                  className={`flex-1 flex items-center justify-center space-x-1.5 py-2 px-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    workspaceTab === 'quiz'
                      ? 'bg-white text-blue-700 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span>Logic Quiz</span>
                </button>
              </div>

              {/* Expand to 90% Screen Modal Button */}
              <button
                type="button"
                onClick={() =>
                  openWorkspaceModal(
                    workspaceTab === 'coding' ? 'coding' : workspaceTab === 'project' ? 'project' : 'quiz'
                  )
                }
                title="Expandir para Modal Centralizado (90% da tela)"
                className="flex items-center space-x-1 px-2.5 py-1.5 ml-1.5 text-slate-500 hover:text-blue-600 hover:bg-white rounded-xl transition cursor-pointer shrink-0 border border-transparent hover:border-slate-200 shadow-2xs text-[11px] font-bold"
              >
                <Maximize2 className="w-3.5 h-3.5 text-blue-600" />
                <span className="hidden sm:inline">90%</span>
              </button>
            </div>

            {/* TAB 1: Live Coding */}
            {workspaceTab === 'coding' && (
              <div className="p-5">
                <LiveCodeEditor />
              </div>
            )}

            {/* TAB 2: Hardware / Maker Lab */}
            {workspaceTab === 'project' && (
              <div className="p-5 space-y-5">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600">
                      Maker &amp; Hardware Lab
                    </span>
                    <span className="text-[11px] font-bold bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full border border-emerald-200">
                      {Object.values(checklist).filter(Boolean).length} of 4 Steps Done
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900">
                    Sensor Angular de Fatias &amp; Protótipo Físico
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Construa um disco fracionário com marcações angulares e teste com sensor de rotação.
                  </p>
                </div>

                {/* 90% Modal Trigger for Project */}
                <button
                  type="button"
                  onClick={() => openWorkspaceModal('project')}
                  className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 text-blue-700 font-bold text-xs transition border border-blue-200/80 flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                >
                  <Maximize2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>Abrir Projeto em Modal Centralizado (90% da Tela)</span>
                </button>

                {/* Required Materials */}
                <div className="bg-slate-50 rounded-2xl p-3.5 border border-slate-200/60">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                    Required Materials
                  </span>
                  <div className="flex items-center space-x-4 text-xs font-semibold text-slate-700">
                    <span className="flex items-center gap-1.5">
                      <Scissors className="w-3.5 h-3.5 text-blue-600" /> Scissors
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Pencil className="w-3.5 h-3.5 text-amber-600" /> Protractor
                    </span>
                    <span className="flex items-center gap-1.5">
                      <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" /> Cardboard
                    </span>
                  </div>
                </div>

                {/* Steps Checklist */}
                <div className="space-y-2.5">
                  <span className="text-xs font-bold text-slate-800">Checklist Instructions:</span>
                  <ChecklistItem
                    id="step-1"
                    stepNumber={1}
                    title="Baixar gabarito de ângulos radianos"
                    subtitle="Arquivo vetorial com divisões em 90°, 180°, 270° e 360°."
                    isChecked={checklist.step1}
                    onToggle={() => toggleChecklist('step1')}
                  />
                  <ChecklistItem
                    id="step-2"
                    stepNumber={2}
                    title="Colorir 3/4 fatias em vermelho (270°)"
                    subtitle="Identifique o ângulo angular equivalente à fração 3/4."
                    isChecked={checklist.step2}
                    onToggle={() => toggleChecklist('step2')}
                  />
                  <ChecklistItem
                    id="step-3"
                    stepNumber={3}
                    title="Rotular índices do array [0, 1, 2] nas fatias"
                    subtitle='Escreva os índices numéricos que o loop for em Python itera.'
                    isChecked={checklist.step3}
                    onToggle={() => toggleChecklist('step3')}
                  />
                  <ChecklistItem
                    id="step-4"
                    stepNumber={4}
                    title="Fotografar protótipo para submissão com IA"
                    subtitle="A visão computacional avaliará o alinhamento angular."
                    isChecked={checklist.step4}
                    onToggle={() => toggleChecklist('step4')}
                  />
                </div>

                {/* Upload Dropzone */}
                <label className="p-4 rounded-2xl bg-slate-50 border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-center cursor-pointer hover:bg-blue-50/50 hover:border-blue-400 transition block">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  {uploadedPhoto ? (
                    <div className="space-y-2 text-center">
                      <img
                        src={uploadedPhoto}
                        alt="Preview do protótipo"
                        className="w-24 h-24 object-cover rounded-xl mx-auto shadow-xs border border-slate-200"
                      />
                      <p className="text-xs font-bold text-emerald-700">Foto Carregada ✓</p>
                      <p className="text-[10px] text-slate-400">Clique para substituir imagem</p>
                    </div>
                  ) : (
                    <>
                      <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mb-2 mx-auto">
                        <Upload className="w-5 h-5" />
                      </div>
                      <p className="text-xs font-bold text-slate-800">Upload Project Photo</p>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        PNG, JPG up to 10MB (Drag &amp; drop or click)
                      </p>
                    </>
                  )}
                </label>

                {/* Download Material Resource Button */}
                <button
                  type="button"
                  onClick={() => showToast('Download do gabarito angular "angles_fraction_template.pdf" iniciado')}
                  className="w-full flex items-center justify-center space-x-2 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition cursor-pointer"
                >
                  <FileDown className="w-4 h-4 text-slate-600" />
                  <span>Download Printable Template PDF</span>
                </button>
              </div>
            )}

            {/* TAB 3: Tech & Logic Quiz */}
            {workspaceTab === 'quiz' && (
              <div className="p-5 space-y-5">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-blue-600">
                      Algorithmic Verification
                    </span>
                    <h3 className="text-base font-bold text-slate-900">Quiz de Código &amp; Geometria</h3>
                  </div>
                  <span className="text-xs font-bold px-2 py-1 bg-blue-50 text-blue-700 rounded-lg">
                    3 Questões
                  </span>
                </div>

                {/* 90% Modal Trigger for Quiz */}
                <button
                  type="button"
                  onClick={() => openWorkspaceModal('quiz')}
                  className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 text-blue-700 font-bold text-xs transition border border-blue-200/80 flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
                >
                  <Maximize2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>Abrir Quiz em Modal Centralizado (90% da Tela)</span>
                </button>

                {/* Question 1: Visual Multi-Choice */}
                <div className="space-y-3">
                  <p className="text-xs font-bold text-slate-800">
                    1. Qual renderização gráfica representa o resultado de{' '}
                    <code className="text-blue-600 font-mono bg-blue-50 px-1 rounded text-xs">
                      (360 / 4) * 3 = 270°
                    </code>{' '}
                    de preenchimento?
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <QuizOptionCard
                      id="opt-a"
                      label="Option A (270° / 3 partes de 4)"
                      fractionVisual={{ total: 4, filled: 3 }}
                      isSelected={selectedQ1 === 'A'}
                      onSelect={() => setSelectedQ1('A')}
                    />
                    <QuizOptionCard
                      id="opt-b"
                      label="Option B (90° / 1 parte de 4)"
                      fractionVisual={{ total: 4, filled: 1 }}
                      isSelected={selectedQ1 === 'B'}
                      onSelect={() => setSelectedQ1('B')}
                    />
                  </div>
                </div>

                {/* Question 2: Python Code Problem */}
                <div className="space-y-2.5 pt-2">
                  <p className="text-xs font-bold text-slate-800 leading-snug">
                    2. Em Python, o que retorna a expressão:{' '}
                    <code className="font-mono text-purple-700 bg-purple-50 px-1 rounded text-xs">
                      slices = [1, 1, 1, 0]; sum(slices) / len(slices)
                    </code>
                    ?
                  </p>
                  <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
                    {['0.25', '0.75', '3.0', '1.0'].map((opt) => (
                      <label
                        key={opt}
                        onClick={() => setSelectedQ2(opt)}
                        className={`flex items-center space-x-2 p-2.5 rounded-xl cursor-pointer border transition ${
                          selectedQ2 === opt
                            ? 'bg-blue-50 border-blue-400 text-blue-900 font-bold'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        <input
                          type="radio"
                          name="q2"
                          checked={selectedQ2 === opt}
                          onChange={() => setSelectedQ2(opt)}
                          className="text-blue-600 focus:ring-blue-500"
                        />
                        <span>{opt} {opt === '0.75' && '(Correta: 3/4)'}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Result banner or action button */}
                {quizScoreBadge ? (
                  <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-center space-y-1">
                    <p className="text-xs font-bold text-emerald-800">{quizScoreBadge}</p>
                    <p className="text-[11px] text-emerald-600">
                      Excelente trabalho! Suas respostas foram salvas no histórico.
                    </p>
                  </div>
                ) : (
                  <Button
                    variant="primary"
                    size="md"
                    className="w-full"
                    onClick={handleCheckQuiz}
                    icon={<Award className="w-4 h-4" />}
                  >
                    Check Answers &amp; Earn Star Badge ⭐
                  </Button>
                )}
              </div>
            )}
          </div>

          {/* Quick Helpful Tutor Card */}
          <div className="bg-gradient-to-r from-indigo-500 to-blue-600 rounded-3xl p-5 text-white shadow-xs flex items-center justify-between">
            <div className="space-y-1">
              <p className="text-xs font-bold uppercase tracking-wider text-indigo-100">
                Need Help with Math &amp; Code?
              </p>
              <p className="text-xs text-indigo-50 font-medium">
                Mom, Dad or Code Mentor are online to assist.
              </p>
            </div>
            <button
              type="button"
              onClick={() => showToast('Conectando chamada ao vivo com o mentor de código')}
              className="bg-white text-blue-700 hover:bg-indigo-50 px-3.5 py-1.5 rounded-xl text-xs font-bold shadow-xs transition cursor-pointer flex items-center gap-1.5"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Call Tutor</span>
            </button>
          </div>
        </aside>
      </div>

      {/* Bottom Sticky Progression Navigation Bar */}
      <footer className="sticky bottom-4 z-30 bg-white/95 backdrop-blur-md p-4 rounded-3xl border border-slate-200/90 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Prev Lesson */}
        <button
          type="button"
          onClick={() => {
            setCurrentPath('lesson-plans');
            showToast('Navegando para Lesson 1: Python Syntax');
          }}
          className="flex items-center space-x-2 text-xs font-semibold text-slate-600 hover:text-blue-600 transition cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Lesson 1: Python Syntax &amp; Storytelling</span>
        </button>

        {/* Mid Progress Summary */}
        <div className="flex items-center space-x-4 w-full sm:w-1/3">
          <div className="flex-1 bg-slate-100 h-2 rounded-full overflow-hidden">
            <div className="bg-emerald-500 h-full rounded-full w-[75%]" />
          </div>
          <span className="text-xs font-bold text-slate-700 whitespace-nowrap tabular-nums">
            75% Concluído
          </span>
        </div>

        {/* Next Lesson */}
        <button
          type="button"
          onClick={() => {
            setCurrentPath('lesson-plans');
            showToast('Navegando para Lesson 3: Algoritmos de Fatiamento');
          }}
          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer"
        >
          <span>Lesson 3: Algoritmos de Fatiamento &amp; Scratch</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </footer>
    </div>
  );
};
