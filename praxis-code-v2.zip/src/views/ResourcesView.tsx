import React from 'react';
import { useApp } from '../context/AppContext';
import { VIDEO_RESOURCES, EXTERNAL_RESOURCES } from '../constants/mockData';
import { VideoCard } from '../components/molecules/VideoCard';
import { FolderOpen, FileText, Download, ExternalLink, Video } from 'lucide-react';

export const ResourcesView: React.FC = () => {
  const { setActiveVideoModal, showToast } = useApp();

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
            <FolderOpen className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Biblioteca de Recursos &amp; Materiais</h2>
            <p className="text-xs text-slate-500">Documentos curriculares, links interativos e acervo multimídia</p>
          </div>
        </div>
      </div>

      {/* Videos Section */}
      <section className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <Video className="w-4 h-4 text-red-600" />
          <span>Aulas em Vídeo e Demonstrações Práticas</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
          {VIDEO_RESOURCES.map((v) => (
            <VideoCard key={v.id} video={v} onPlay={(video) => setActiveVideoModal(video)} />
          ))}
        </div>
      </section>

      {/* Playgrounds & External Portals */}
      <section className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-4">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <ExternalLink className="w-4 h-4 text-blue-600" />
          <span>Playgrounds de Geometria e Código</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {EXTERNAL_RESOURCES.map((res) => (
            <a
              key={res.id}
              href={res.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-4 rounded-2xl border border-slate-200 bg-slate-50/60 hover:bg-blue-50/50 hover:border-blue-300 transition flex items-start justify-between group"
            >
              <div>
                <div className="flex items-center space-x-2">
                  <h4 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition">
                    {res.title}
                  </h4>
                  <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-blue-100 text-blue-800">
                    {res.category}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">{res.description}</p>
              </div>
              <ExternalLink className="w-4 h-4 text-slate-400 group-hover:text-blue-600 shrink-0 ml-3" />
            </a>
          ))}
        </div>
      </section>

      {/* Curriculum PDF Downloads */}
      <section className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs space-y-3">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <FileText className="w-4 h-4 text-emerald-600" />
          <span>Manuais Pedagógicos &amp; BNCC</span>
        </h3>
        <div className="space-y-2">
          {[
            { name: 'Guia Curricular BNCC 2º Ano - Matemática e Pensamento Computacional.pdf', size: '2.4 MB' },
            { name: 'Planilhas de Registro de Observação Formativa e Frequência.pdf', size: '1.1 MB' },
            { name: 'Roteiros de Projetos Maker e STEM para Homeschooling.pdf', size: '4.8 MB' },
          ].map((doc, idx) => (
            <div
              key={idx}
              onClick={() => showToast(`Download do arquivo "${doc.name}" iniciado`)}
              className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 hover:bg-slate-100 border border-slate-200 transition cursor-pointer"
            >
              <div className="flex items-center space-x-3">
                <FileText className="w-4 h-4 text-blue-600" />
                <span className="text-xs font-semibold text-slate-800">{doc.name}</span>
              </div>
              <div className="flex items-center space-x-3 text-xs text-slate-400 font-medium">
                <span>{doc.size}</span>
                <Download className="w-4 h-4 text-slate-600 hover:text-blue-600" />
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
