import React from 'react';
import { useApp } from '../context/AppContext';
import { Users, Flame, Award, CheckCircle2, AlertTriangle, ArrowUpRight } from 'lucide-react';
import { ProgressBar } from '../components/atoms/ProgressBar';

export const StudentsView: React.FC = () => {
  const { students, showToast } = useApp();

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Roster de Alunos &amp; Desempenho</h2>
            <p className="text-xs text-slate-500">Métricas individuais de aprendizagem, ofensivas e diagnósticos</p>
          </div>
        </div>
        <span className="px-3 py-1 bg-blue-50 text-blue-700 text-xs font-bold rounded-full border border-blue-200">
          {students.length} Alunos Matriculados
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {students.map((student) => (
          <div
            key={student.id}
            className={`p-6 rounded-3xl border transition-all duration-200 ${
              student.hasAlert
                ? 'bg-rose-50/50 border-rose-200 shadow-xs'
                : 'bg-white border-slate-200/80 shadow-xs hover:shadow-md'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-3.5">
                <div
                  className={`w-12 h-12 rounded-2xl ${student.avatarColor} text-white font-bold text-base flex items-center justify-center shadow-xs`}
                >
                  {student.initials}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-900">{student.name}</h3>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                      {student.grade}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Nível {student.level} • {student.xp.toLocaleString()} XP Conquistados
                  </p>
                </div>
              </div>

              <span className="flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                <Flame className="w-3.5 h-3.5 fill-current" />
                {student.streakDays} Dias
              </span>
            </div>

            {student.hasAlert && (
              <div className="mt-4 p-3 bg-rose-100/60 rounded-xl border border-rose-200 text-xs text-rose-800 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <p className="leading-snug">
                  <strong>Atenção:</strong> {student.alertText}
                </p>
              </div>
            )}

            <div className="mt-5 space-y-2">
              <div className="flex justify-between text-xs font-semibold text-slate-600">
                <span>Progresso Curricular do Trimestre</span>
                <span className="text-blue-600 font-bold">{student.progressPercent}%</span>
              </div>
              <ProgressBar
                value={student.progressPercent}
                color={student.hasAlert ? 'rose' : student.progressPercent > 80 ? 'emerald' : 'blue'}
                size="sm"
              />
            </div>

            <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-medium">Status: {student.statusText}</span>
              <button
                type="button"
                onClick={() => showToast(`Dossiê individual de ${student.name} gerado`)}
                className="text-blue-600 hover:text-blue-800 font-bold flex items-center gap-1 cursor-pointer"
              >
                <span>Ficha Completa</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
