import React from 'react';
import { useApp } from '../context/AppContext';
import { WeeklyLessonPlanner } from '../components/organisms/WeeklyLessonPlanner';
import { Calendar, Clock, BookOpen, CheckCircle } from 'lucide-react';

export const WeeklyPlanView: React.FC = () => {
  const { lessons, role, setCurrentPath, setActiveLessonId } = useApp();

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Grade Horária &amp; Plano Semanal</h2>
            <p className="text-xs text-slate-500">Distribuição equilibrada de atividades cognitivas, STEM e artísticas</p>
          </div>
        </div>
        <span className="px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-full border border-emerald-200">
          Semana 12 (Em Andamento)
        </span>
      </div>

      <WeeklyLessonPlanner />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-2">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-600" />
            <span>Carga Horária Semanal</span>
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Meta pedagógica de 30 horas cumprida em 95%. Recomendado intercalar períodos de tela com projetos manuais.
          </p>
        </div>

        <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-2">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-emerald-600" />
            <span>Marcos BNCC Cobertos</span>
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            EF02MA06 (Frações e medidas), EF02LP01 (Fonologia e leitura) e habilidades computacionais CSTA integradas.
          </p>
        </div>

        <div className="bg-white rounded-3xl p-5 border border-slate-200/80 shadow-xs space-y-2">
          <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-purple-600" />
            <span>Avaliação Contínua</span>
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Acompanhamento automatizado por rubricas com feedback instantâneo via IA em desafios de programação.
          </p>
        </div>
      </div>
    </div>
  );
};
