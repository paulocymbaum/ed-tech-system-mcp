import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { WeeklyStreakBanner } from '../components/organisms/WeeklyStreakBanner';
import { MetricStatCard } from '../components/molecules/MetricStatCard';
import { WeeklyActivityList } from '../components/organisms/WeeklyActivityList';
import { WeeklyActivityKanban } from '../components/organisms/WeeklyActivityKanban';
import { List, Columns, ChevronDown } from 'lucide-react';

export const StudentDashboardView: React.FC = () => {
  const { setCurrentPath, setActiveLessonId } = useApp();
  const [viewMode, setViewMode] = useState<'list' | 'kanban'>('list');
  const [selectedWeek, setSelectedWeek] = useState('Week 1');

  const handleOpenLesson2 = () => {
    setActiveLessonId('lesson-2');
    setCurrentPath('lesson-plans');
  };

  const handleOpenLesson5 = () => {
    setActiveLessonId('lesson-5');
    setCurrentPath('lesson-plans');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Interactive Streak & Daily Milestone Widget */}
      <WeeklyStreakBanner />

      {/* Quick Summary Widgets Row */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-4" data-purpose="quick-summary-widgets">
        <MetricStatCard
          icon="🪐"
          iconBg="bg-indigo-50 border-indigo-100"
          iconColor="text-indigo-600"
          categoryLabel="Active Project"
          title="Pygame Orbital Simulation"
          badgeText="Due Friday"
          badgeVariant="amber"
          onClick={handleOpenLesson5}
        />
        <MetricStatCard
          icon="📐"
          iconBg="bg-emerald-50 border-emerald-100"
          iconColor="text-emerald-600"
          categoryLabel="Next Up (10:30 AM)"
          title="Fractions & Python Turtle"
          badgeText="Lesson 2"
          badgeVariant="blue"
          onClick={handleOpenLesson2}
        />
        <MetricStatCard
          icon="⏱️"
          iconBg="bg-purple-50 border-purple-100"
          iconColor="text-purple-600"
          categoryLabel="Weekly Goal (3h 30m)"
          title="2h 15m Finished"
          badgeText="64% Done"
          badgeVariant="emerald"
        />
      </section>

      {/* Weekly Activity Toolbar Header */}
      <section className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
        <div className="flex items-center space-x-3">
          <h2 className="text-xl font-bold text-slate-900 tracking-tight">Weekly Activity</h2>
          <span className="bg-slate-200/80 text-slate-700 text-xs font-semibold px-2.5 py-0.5 rounded-full">
            5 Lessons
          </span>
        </div>

        <div className="flex items-center space-x-3 self-end sm:self-auto">
          {/* Week Selector Dropdown */}
          <div className="flex items-center space-x-2 text-xs font-medium text-slate-500">
            <span>Next Week :</span>
            <div className="relative inline-block text-left">
              <button
                type="button"
                className="bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold px-3 py-1.5 rounded-xl flex items-center space-x-2 shadow-2xs text-xs transition-colors cursor-pointer"
              >
                <span>{selectedWeek}</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>
            </div>
          </div>

          {/* View Mode Toggle: Kanban vs List */}
          <div className="flex items-center bg-slate-200/80 p-1 rounded-xl text-xs font-medium border border-slate-200/80">
            <button
              type="button"
              onClick={() => setViewMode('kanban')}
              className={`flex items-center space-x-1.5 px-3 py-1 rounded-lg transition-all cursor-pointer ${
                viewMode === 'kanban'
                  ? 'bg-blue-600 text-white font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Columns className="w-3.5 h-3.5" />
              <span>Kanban</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('list')}
              className={`flex items-center space-x-1.5 px-3 py-1 rounded-lg transition-all cursor-pointer ${
                viewMode === 'list'
                  ? 'bg-blue-600 text-white font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>List</span>
            </button>
          </div>
        </div>
      </section>

      {/* Weekly Activity Container */}
      <section>
        {viewMode === 'list' ? (
          <WeeklyActivityList onSelectLesson={() => setCurrentPath('lesson-plans')} />
        ) : (
          <WeeklyActivityKanban />
        )}
      </section>
    </div>
  );
};
