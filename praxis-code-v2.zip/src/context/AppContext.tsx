import React, { createContext, useContext, useState } from 'react';
import { UserRole, NavigationPath, ILesson, IStudent, IGradingSubmission, IVideoResource } from '../types';
import { INITIAL_LESSONS, INITIAL_STUDENTS, INITIAL_SUBMISSIONS } from '../constants/mockData';

export type WorkspaceModalMode = 'quiz' | 'project' | 'coding';

export interface WorkspaceModalState {
  isOpen: boolean;
  mode: WorkspaceModalMode;
  lessonId: string;
}

interface AppContextType {
  role: UserRole;
  setRole: (role: UserRole) => void;
  currentPath: NavigationPath;
  setCurrentPath: (path: NavigationPath) => void;
  activeLessonId: string;
  setActiveLessonId: (id: string) => void;
  lessons: ILesson[];
  students: IStudent[];
  submissions: IGradingSubmission[];
  approveSubmission: (id: string, customScore?: number) => void;
  approveAllAiSubmissions: () => void;
  addLesson: (lesson: Partial<ILesson>) => void;
  activeStudent: IStudent;
  selectedSlices: number[];
  toggleSlice: (sliceIndex: number) => void;
  resetSlices: () => void;
  activeVideoModal: IVideoResource | null;
  setActiveVideoModal: (video: IVideoResource | null) => void;
  workspaceModal: WorkspaceModalState;
  openWorkspaceModal: (mode: WorkspaceModalMode, lessonId?: string) => void;
  closeWorkspaceModal: () => void;
  setWorkspaceModalMode: (mode: WorkspaceModalMode) => void;
  isSidebarCollapsed: boolean;
  toggleSidebar: () => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
  updateLessonProgress: (lessonId: string, delta: Partial<ILesson>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRoleState] = useState<UserRole>('student');
  const [currentPath, setCurrentPath] = useState<NavigationPath>('dashboard');
  const [activeLessonId, setActiveLessonId] = useState<string>('lesson-2');
  const [lessons, setLessons] = useState<ILesson[]>(INITIAL_LESSONS);
  const [students, setStudents] = useState<IStudent[]>(INITIAL_STUDENTS);
  const [submissions, setSubmissions] = useState<IGradingSubmission[]>(INITIAL_SUBMISSIONS);
  const [selectedSlices, setSelectedSlices] = useState<number[]>([1, 2, 3]); // Slices 1, 2, 3 active (3/4)
  const [activeVideoModal, setActiveVideoModal] = useState<IVideoResource | null>(null);
  const [workspaceModal, setWorkspaceModal] = useState<WorkspaceModalState>({
    isOpen: false,
    mode: 'quiz',
    lessonId: 'lesson-2',
  });
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const openWorkspaceModal = (mode: WorkspaceModalMode, lessonId?: string) => {
    setWorkspaceModal({
      isOpen: true,
      mode,
      lessonId: lessonId || activeLessonId,
    });
  };

  const closeWorkspaceModal = () => {
    setWorkspaceModal((prev) => ({ ...prev, isOpen: false }));
  };

  const setWorkspaceModalMode = (mode: WorkspaceModalMode) => {
    setWorkspaceModal((prev) => ({ ...prev, mode }));
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 3200);
  };

  const setRole = (newRole: UserRole) => {
    setRoleState(newRole);
    showToast(`Alternado para Modo ${newRole === 'teacher' ? 'Professor' : 'Estudante'}`);
  };

  const toggleSidebar = () => {
    setIsSidebarCollapsed((prev) => !prev);
  };

  const toggleSlice = (sliceIndex: number) => {
    setSelectedSlices((prev) => {
      if (prev.includes(sliceIndex)) {
        return prev.filter((i) => i !== sliceIndex);
      } else {
        return [...prev, sliceIndex].sort((a, b) => a - b);
      }
    });
  };

  const resetSlices = () => {
    setSelectedSlices([1, 2, 3]);
  };

  const approveSubmission = (id: string, customScore?: number) => {
    setSubmissions((prev) =>
      prev.map((sub) =>
        sub.id === id
          ? {
              ...sub,
              status: 'approved',
              suggestedScore: customScore ?? sub.suggestedScore,
            }
          : sub
      )
    );
    showToast(`Nota aprovada com sucesso!`);
  };

  const approveAllAiSubmissions = () => {
    setSubmissions((prev) =>
      prev.map((sub) => ({ ...sub, status: 'approved' }))
    );
    showToast(`Todas as 12 avaliações de IA foram aprovadas em lote!`);
  };

  const addLesson = (newLessonData: Partial<ILesson>) => {
    const nextNumber = lessons.length + 1;
    const newLesson: ILesson = {
      id: `lesson-${nextNumber}`,
      number: nextNumber,
      title: newLessonData.title || `Lesson ${nextNumber}: Nova Lição`,
      subtitle: newLessonData.subtitle || 'Planejada',
      day: newLessonData.day || 'Próxima Semana',
      subject: newLessonData.subject || 'Geral',
      unit: newLessonData.unit || 'Unit 1',
      level: newLessonData.level || 'Beginner',
      status: 'Not Started',
      projectsCompleted: 0,
      projectsTotal: 2,
      quizzesCompleted: 0,
      quizzesTotal: 2,
      tasksCompleted: 0,
      tasksTotal: 4,
      durationMins: newLessonData.durationMins || 45,
      audioDuration: '05:00',
      audioCurrent: '00:00',
      description: newLessonData.description || 'Nova atividade atribuída.',
      scoreStatus: 'None',
    };
    setLessons((prev) => [...prev, newLesson]);
    showToast(`Nova lição criada com sucesso!`);
  };

  const updateLessonProgress = (lessonId: string, delta: Partial<ILesson>) => {
    setLessons((prev) =>
      prev.map((l) => (l.id === lessonId ? { ...l, ...delta } : l))
    );
  };

  const activeStudent = students[0]; // Jane Cooper

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        currentPath,
        setCurrentPath,
        activeLessonId,
        setActiveLessonId,
        lessons,
        students,
        submissions,
        approveSubmission,
        approveAllAiSubmissions,
        addLesson,
        activeStudent,
        selectedSlices,
        toggleSlice,
        resetSlices,
        activeVideoModal,
        setActiveVideoModal,
        workspaceModal,
        openWorkspaceModal,
        closeWorkspaceModal,
        setWorkspaceModalMode,
        isSidebarCollapsed,
        toggleSidebar,
        toastMessage,
        showToast,
        updateLessonProgress,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
